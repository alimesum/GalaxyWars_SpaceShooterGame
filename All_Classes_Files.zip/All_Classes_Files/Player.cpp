#include "Player.h"
#include <iostream>

using namespace std;
using namespace sf;

int Player::totalPlayers = 0;

Player::Player(float startX, float startY) 
    : GameObject(startX, startY), health(100), maxHealth(100), 
      score(0), fireRate(0.3f), fireTimer(0), shieldActive(false), 
      shieldTimer(0), weaponLevel(1), collectedResources(0, 0, 0),
      maxX(800), maxY(600) {
    speed = 5.0f;
    totalPlayers++;
    
    if (!texture.loadFromFile("assets/player.png")) {
        cerr << "ERROR: Failed to load player.png - File missing!\n";
    }
    texture.setSmooth(false);
    
    if (!shieldTexture.loadFromFile("assets/ShieldedPlayer.png")) {
        cerr << "ERROR: Failed to load ShieldedPlayer.png - File missing!\n";
        shieldTexture = texture;
    }    
    sprite.setTexture(texture);
    
    // IMPORTANT: Set origin to center in constructor
    FloatRect bounds = sprite.getLocalBounds();
    sprite.setOrigin(bounds.width / 2.0f, bounds.height / 2.0f);
    
    float targetSize = 60.0f;
    sprite.setScale(targetSize / bounds.width, targetSize / bounds.height);
    
    sprite.setPosition(x, y);
}

Player::~Player() {
    totalPlayers--;
}

void Player::setBoundaries(float maxWidth, float maxHeight) {
    FloatRect bounds = sprite.getGlobalBounds();
    float spriteHalfWidth = bounds.width / 2.0f;
    float spriteHalfHeight = bounds.height / 2.0f;
    
    maxX = maxWidth - spriteHalfWidth;
    maxY = maxHeight - spriteHalfHeight;
}

void Player::update() {
    sprite.setPosition(x, y);
    
    if (fireTimer > 0) {
        fireTimer -= 0.016f;
    }
    
    if (shieldTimer > 0) {
        shieldTimer -= 0.016f;
        if (shieldTimer <= 0) {
            shieldActive = false;
            sprite.setTexture(texture);
            
            FloatRect bounds = sprite.getLocalBounds();
            sprite.setOrigin(bounds.width / 2.0f, bounds.height / 2.0f);
            
            float targetSize = 60.0f;
            sprite.setScale(targetSize / bounds.width, targetSize / bounds.height);
        }
    }
}

void Player::draw(RenderWindow& window) {
    if (active) {
        window.draw(sprite);
    }
}

FloatRect Player::getBounds() const {
    return sprite.getGlobalBounds();
}

void Player::move(float dx, float dy) {
    x += dx * speed;
    y += dy * speed;
    
    FloatRect bounds = sprite.getGlobalBounds();
    float spriteHalfWidth = bounds.width / 2.0f;
    float spriteHalfHeight = bounds.height / 2.0f;
    
    if (x < spriteHalfWidth) x = spriteHalfWidth;
    if (x > maxX) x = maxX;
    if (y < spriteHalfHeight) y = spriteHalfHeight;
    if (y > maxY) y = maxY;
}

bool Player::canFire() {
    return fireTimer <= 0;
}

void Player::resetFireTimer() {
    fireTimer = fireRate;
}

void Player::takeDamage(int damage) {
    if (!shieldActive) {
        health -= damage;
        if (health < 0) health = 0;
    }
}

void Player::heal(int amount) {
    health += amount;
    if (health > maxHealth) health = maxHealth;
}

void Player::addScore(int points) {
    score += points;
}

void Player::activateShield(float duration) {
    shieldActive = true;
    shieldTimer = duration;
    sprite.setTexture(shieldTexture);
    
    FloatRect bounds = sprite.getLocalBounds();
    sprite.setOrigin(bounds.width / 2.0f, bounds.height / 2.0f);
    
    float targetSize = 100.0f; 
    sprite.setScale(targetSize / bounds.width, targetSize / bounds.height);
}

void Player::setFireRate(float rate) {
    fireRate = rate;
}

void Player::addResources(const Resource& res) {
    collectedResources += res;
    
    int totalValue = collectedResources.getTotalValue();
    if (totalValue >= 50 && weaponLevel < 3) {
        upgradeWeapon();
    }
}

Resource Player::getResources() const {
    return collectedResources;
}

void Player::upgradeWeapon() {
    weaponLevel++;
    if (weaponLevel > 3) weaponLevel = 3;
    addScore(50);
}

int Player::getWeaponLevel() const {
    return weaponLevel;
}

int Player::getProjectileDamage() const {
    return 10 * weaponLevel;
}

int Player::getHealth() const {
    return health;
}

int Player::getScore() const {
    return score;
}

bool Player::hasShield() const {
    return shieldActive;
}

Vector2f Player::getPosition() const {
    return Vector2f(x, y);
}

int Player::getTotalPlayers() {
    return totalPlayers;
}

void displayPlayerStats(const Player& player) {
    cout << "Player Stats - Health: " << player.health 
         << " Score: " << player.score << endl;
}
