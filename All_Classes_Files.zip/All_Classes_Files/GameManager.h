#ifndef GAMEMANAGER_H
#define GAMEMANAGER_H

#include <string>
#include "Player.h"
#include "Enemy.h"
#include "BasicEnemy.h"
#include "AdvancedEnemy.h"
#include "AggressiveEnemy.h"
#include "Boss.h"
#include "Projectile.h"
#include "Asteroid.h"
#include "PowerUp.h"
#include "ShieldPowerUp.h"
#include "HealthPowerUp.h"
#include "FireRatePowerUp.h"
#include "ResourcePowerUp.h"
#include "Resource.h"
#include "ScoreManager.h"
#include "Explosion.h"
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <ctime>

class GameManager {
private:
    Player* player;
    Enemy** enemies;
    Boss* boss;
    Projectile** projectiles;
    Asteroid** asteroids;
    PowerUp** powerups;
    Explosion** explosions;
    
    int maxEnemies;
    int maxProjectiles;
    int maxAsteroids;
    int maxPowerups;
    int maxExplosions;
    
    int enemyCount;
    int projectileCount;
    int asteroidCount;
    int powerupCount;
    int explosionCount;
    
    int currentLevel;
    int waveNumber;
    float spawnTimer;
    float powerupTimer;
    bool victory;
    float bossSpawnTimer;
    
    Resource collectedResources;
    ScoreManager* scoreManager;
    
    bool paused;
    bool gameOver;
    bool levelTransition;
    bool bossWarning;
    float transitionTimer;
    float blinkTimer;
    bool textVisible;
    
    sf::Texture backgroundTex;
    sf::Sprite background;
    
    sf::Font font;
    sf::Text scoreText;
    sf::Text healthText;
    sf::Text levelText;
    sf::Text gameOverText;
    sf::Text pauseText;
    sf::Text transitionText;
    sf::Text bossWarningText;
    sf::Text bossHealthText;
    
    clock_t startTime;
    
    float windowWidth;
    float windowHeight;
    
    sf::Music level1Music;
    sf::Music level2Music;
    sf::Music level3Music;
    sf::Music gameOverMusic;
    sf::Music bossMusic;
    
    sf::SoundBuffer shootBuffer;
    sf::SoundBuffer enemyDeathBuffer;
    sf::SoundBuffer powerupBuffer;
    sf::SoundBuffer gameOverBuffer;
    sf::SoundBuffer explosionBuffer;
    sf::SoundBuffer bossWarningBuffer;
    
    sf::Sound shootSound;
    sf::Sound enemyDeathSound;
    sf::Sound powerupSound;
    sf::Sound gameOverSound;
    sf::Sound explosionSound;
    sf::Sound bossWarningSound;
    
    int previousLevel;
    bool bossSpawned;
    
    std::string playerName; 
    int startingLevel;
    
    void spawnEnemies();
    void spawnPowerup();
    void spawnBoss();
    void bossFire();
    void checkCollisions();
    void cleanupInactive();
    void updateLevel();
    void renderUI(sf::RenderWindow& window);
    void playLevelMusic(int level);
    void createExplosion(float x, float y);
    void startLevelTransition(int newLevel);
    void startBossWarning();
    
public:
    GameManager(float winWidth, float winHeight);
    ~GameManager();
    
    void init();
    void update();
    void render(sf::RenderWindow& window);
    void handleInput(sf::Keyboard::Key key);
    void shoot();
    void togglePause();
    void restart();
    
    void setPlayerName(std::string name);  
    void setStartingLevel(int level);
    
    bool isGameOver() const;
    bool isPaused() const;
    int getFinalScore() const;
    bool isVictory() const;
    
    sf::Font& getFont(); 
    float getWindowWidth() const;
    float getWindowHeight() const;
};

#endif
