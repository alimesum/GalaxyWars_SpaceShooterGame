#ifndef SHIELDPOWERUP_H
#define SHIELDPOWERUP_H

#include "PowerUp.h"
#include "Player.h"

class ShieldPowerUp : public PowerUp {
public:
    ShieldPowerUp(float startX, float startY);
    void applyEffect(Player& player) override;
};

#endif
