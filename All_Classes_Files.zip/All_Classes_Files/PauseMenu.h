#ifndef PAUSEMENU_H
#define PAUSEMENU_H

#include <SFML/Graphics.hpp>

class PauseMenu {
private:

    sf::Texture backgroundTex;
    sf::Sprite background;
    
    sf::Font font;
    sf::RectangleShape overlay;
    sf::RectangleShape menuBox;
    
    sf::Text titleText;
    sf::RectangleShape resumeButton;
    sf::RectangleShape mainMenuButton;
    sf::RectangleShape exitButton;
    
    sf::Text resumeText;
    sf::Text mainMenuText;
    sf::Text exitText;
    
public:
    PauseMenu();
    bool loadAssets(sf::Font& gameFont);
    void handleHover(sf::Vector2f mousePos);
    int handleClick(sf::Vector2f mousePos);
    void draw(sf::RenderWindow& window);
};

#endif
