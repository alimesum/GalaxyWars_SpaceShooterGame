#include "Explosion.h"
#include <iostream>

using namespace std;
using namespace sf;

Explosion::Explosion(float startX, float startY) 
    : GameObject(startX, startY), lifetime(0), maxLifetime(0.5f), scale(1.0f) {
    
    if (!texture.loadFromFile("assets/blast.png")) {
        cerr << "ERROR: Failed to load explosion.png\n";
    }
    texture.setSmooth(false);
    
    sprite.setTexture(texture);
    
    // Center origin
    FloatRect bounds = sprite.getLocalBounds();
    sprite.setOrigin(bounds.width / 2.0f, bounds.height / 2.0f);
    
    float targetSize = 64.0f;
    scale = targetSize / bounds.width;
    sprite.setScale(scale, scale);
    
    sprite.setPosition(x, y);
}

void Explosion::update() {
    lifetime += 0.016f;
    
    // Grow and fade out effect
    float progress = lifetime / maxLifetime;
    float currentScale = scale * (1.0f + progress * 0.5f);
    sprite.setScale(currentScale, currentScale);
    
    // Fade out
    int alpha = 255 * (1.0f - progress);
    if (alpha < 0) alpha = 0;
    sprite.setColor(Color(255, 255, 255, alpha));
    
    // Deactivate when lifetime expires
    if (lifetime >= maxLifetime) {
        active = false;
    }
}

void Explosion::draw(RenderWindow& window) {
    if (active) {
        window.draw(sprite);
    }
}

FloatRect Explosion::getBounds() const {
    return sprite.getGlobalBounds();
}

bool Explosion::isFinished() const {
    return !active;
}
