#ifndef GAMEEXCEPTION_H
#define GAMEEXCEPTION_H

#include <string>

class GameException {
private:
    std::string message;
    int errorCode;
    
public:
    GameException(const std::string& msg, int code = 0);
    
    const char* what() const;
    std::string getMessage() const;
    int getErrorCode() const;
};

// Specific exception types
class FileLoadException : public GameException {
public:
    FileLoadException(const std::string& filename);
};

class InvalidOperationException : public GameException {
public:
    InvalidOperationException(const std::string& operation);
};

#endif
