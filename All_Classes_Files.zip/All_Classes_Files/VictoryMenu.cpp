#include "VictoryMenu.h"
#include<iostream>

using namespace sf;
using namespace std;

VictoryMenu::VictoryMenu() {
    if (!backgroundTex.loadFromFile("assets/b1.jpg")) {
        cout << "Failed to load victory background image!\n";
    }
    background.setTexture(backgroundTex);
    
    overlay.setSize(Vector2f(1920, 1080));
    overlay.setFillColor(Color(0, 0, 0, 200));
    
    menuBox.setSize(Vector2f(600, 500));
    menuBox.setFillColor(Color(20, 40, 60));
    menuBox.setOutlineThickness(5);
    menuBox.setOutlineColor(Color(255, 215, 0));
    
    titleText.setString("VICTORY!");
    titleText.setCharacterSize(48);
    titleText.setFillColor(Color(255, 215, 0));
    
    congratsText.setString("You Defeated The Boss!");
    congratsText.setCharacterSize(24);
    congratsText.setFillColor(Color::Cyan);
    
    scoreText.setCharacterSize(20);
    scoreText.setFillColor(Color::White);
    
    highScoreText.setCharacterSize(18);
    highScoreText.setFillColor(Color::Yellow);
    
    remarksText.setString("Thanks for playing!");
    remarksText.setCharacterSize(16);
    remarksText.setFillColor(Color(150, 255, 150));
    
    restartButton.setSize(Vector2f(250, 60));
    mainMenuButton.setSize(Vector2f(250, 60));
    
    restartButton.setFillColor(Color(0, 150, 0));
    mainMenuButton.setFillColor(Color(0, 100, 200));
    
    restartButton.setOutlineThickness(3);
    mainMenuButton.setOutlineThickness(3);
    
    restartButton.setOutlineColor(Color::White);
    mainMenuButton.setOutlineColor(Color::White);
    
    restartText.setString("RESTART");
    mainMenuText.setString("MAIN MENU");
    
    restartText.setCharacterSize(20);
    mainMenuText.setCharacterSize(20);
    
    restartText.setFillColor(Color::White);
    mainMenuText.setFillColor(Color::White);
}


bool VictoryMenu::loadAssets(Font& gameFont) {
    font = gameFont;
    titleText.setFont(font);
    congratsText.setFont(font);
    scoreText.setFont(font);
    highScoreText.setFont(font);
    remarksText.setFont(font);
    restartText.setFont(font);
    mainMenuText.setFont(font);
    return true;
}

void VictoryMenu::setScoreData(int score, int highScore, string playerName) {
    string scoreStr = "";
    int temp = score;
    if (temp == 0) scoreStr = "0";
    else {
        while (temp > 0) {
            scoreStr = char('0' + (temp % 10)) + scoreStr;
            temp /= 10;
        }
    }
    
    string highScoreStr = "";
    temp = highScore;
    if (temp == 0) highScoreStr = "0";
    else {
        while (temp > 0) {
            highScoreStr = char('0' + (temp % 10)) + highScoreStr;
            temp /= 10;
        }
    }
    
    scoreText.setString("Your Score: " + scoreStr);
    highScoreText.setString("High Score: " + highScoreStr);
    
    if (score >= highScore && highScore > 0) {
        remarksText.setString("NEW HIGH SCORE!\nYou are a legend!\nThe galaxy is saved!");
        remarksText.setFillColor(Color(255, 215, 0));
    } else if (score > 1500) {
        remarksText.setString("OUTSTANDING!\nBoss destroyed!\nIncredible work!");
        remarksText.setFillColor(Color(0, 255, 255));
    } else if (score > 1000) {
        remarksText.setString("EXCELLENT!\nVictory achieved!\nGreat job, warrior!");
        remarksText.setFillColor(Color(0, 255, 0));
    } else if (score > 500) {
        remarksText.setString("GREAT JOB!\nYou won the battle!\nThanks for playing!");
        remarksText.setFillColor(Color(150, 255, 150));
    } else {
        remarksText.setString("VICTORY!\nYou defeated the boss!\nKeep improving!");
        remarksText.setFillColor(Color(200, 200, 255));
    }
}

void VictoryMenu::handleHover(Vector2f mousePos) {
    if (restartButton.getGlobalBounds().contains(mousePos)) {
        restartButton.setFillColor(Color(0, 200, 0));
    } else {
        restartButton.setFillColor(Color(0, 150, 0));
    }
    
    if (mainMenuButton.getGlobalBounds().contains(mousePos)) {
        mainMenuButton.setFillColor(Color(0, 150, 255));
    } else {
        mainMenuButton.setFillColor(Color(0, 100, 200));
    }
}

int VictoryMenu::handleClick(Vector2f mousePos) {
    if (restartButton.getGlobalBounds().contains(mousePos)) {
        return 1;
    }
    if (mainMenuButton.getGlobalBounds().contains(mousePos)) {
        return 2;
    }
    return 0;
}

void VictoryMenu::draw(sf::RenderWindow& window) {
    // Get window size
    float screenW = static_cast<float>(window.getSize().x);
    float screenH = static_cast<float>(window.getSize().y);
    
    Vector2u texSize = backgroundTex.getSize();
    if (texSize.x > 0 && texSize.y > 0) {
        // Scale background to fill entire window
        float scaleX = screenW / texSize.x;
        float scaleY = screenH / texSize.y;
        background.setScale(scaleX, scaleY);
        background.setPosition(0, 0);
        window.draw(background);
    }
    
    overlay.setSize(sf::Vector2f(screenW, screenH));
    overlay.setPosition(0, 0);
    window.draw(overlay);
    
    float boxWidth  = 600.f;
    float boxHeight = 500.f;
    float boxX = (screenW - boxWidth) / 2.f;
    float boxY = (screenH - boxHeight) / 2.f;

    menuBox.setSize(sf::Vector2f(boxWidth, boxHeight));
    menuBox.setPosition(boxX, boxY);
    window.draw(menuBox);

    // Title
    FloatRect titleBounds = titleText.getLocalBounds();
    titleText.setPosition(
        boxX + boxWidth / 2.f - titleBounds.width / 2.f,
        boxY + 30.f
    );
    window.draw(titleText);

    // "You defeated the boss"
    FloatRect congratsBounds = congratsText.getLocalBounds();
    congratsText.setPosition(
        boxX + boxWidth / 2.f - congratsBounds.width / 2.f,
        boxY + 100.f
    );
    window.draw(congratsText);

    // Score
    FloatRect scoreBounds = scoreText.getLocalBounds();
    scoreText.setPosition(
        boxX + boxWidth / 2.f - scoreBounds.width / 2.f,
        boxY + 160.f
    );
    window.draw(scoreText);

    // High score
    FloatRect highScoreBounds = highScoreText.getLocalBounds();
    highScoreText.setPosition(
        boxX + boxWidth / 2.f - highScoreBounds.width / 2.f,
        boxY + 200.f
    );
    window.draw(highScoreText);

    // Remarks
    FloatRect remarksBounds = remarksText.getLocalBounds();
    remarksText.setPosition(
        boxX + boxWidth / 2.f - remarksBounds.width / 2.f,
        boxY + 260.f
    );
    window.draw(remarksText);

    // Buttons (fixed size, inside small area)
    float buttonWidth  = 250.f;
    float buttonHeight = 60.f;

    restartButton.setSize(sf::Vector2f(buttonWidth, buttonHeight));
    mainMenuButton.setSize(sf::Vector2f(buttonWidth, buttonHeight));

    restartButton.setPosition(boxX + 50.f, boxY + 380.f);
    mainMenuButton.setPosition(boxX + boxWidth - buttonWidth - 50.f, boxY + 380.f);

    window.draw(restartButton);
    window.draw(mainMenuButton);

    FloatRect restartBounds = restartText.getLocalBounds();
    FloatRect menuBounds    = mainMenuText.getLocalBounds();

    restartText.setPosition(
        restartButton.getPosition().x + buttonWidth / 2.f - restartBounds.width / 2.f,
        restartButton.getPosition().y + buttonHeight / 2.f - restartBounds.height / 2.f - restartBounds.top
    );
    mainMenuText.setPosition(
        mainMenuButton.getPosition().x + buttonWidth / 2.f - menuBounds.width / 2.f,
        mainMenuButton.getPosition().y + buttonHeight / 2.f - menuBounds.height / 2.f - menuBounds.top
    );

    window.draw(restartText);
    window.draw(mainMenuText);
}
