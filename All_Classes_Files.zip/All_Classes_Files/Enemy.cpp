#include "Enemy.h"

using namespace sf;

Enemy::Enemy(float startX, float startY, int hp, int score) 
    : GameObject(startX, startY), health(hp), scoreValue(score), maxHealth(hp) {
    speed = 2.0f;
}

Enemy::~Enemy() {
    // Destructor
}

void Enemy::draw(RenderWindow& window) {
    if (active) {
        window.draw(sprite);
    }
}

FloatRect Enemy::getBounds() const {
    return sprite.getGlobalBounds();
}

void Enemy::takeDamage(int damage) {
    health -= damage;
    if (health <= 0) {
        active = false;
    }
}

int Enemy::getScoreValue() const {
    return scoreValue;
}

void Enemy::setTarget(float playerX) {
    // Default implementation - can be overridden in derived classes
}

float Enemy::getX() const {
    return x;
}

float Enemy::getY() const {
    return y;
}

float Enemy::getSpeed() const {
    return speed;
}

void Enemy::setEnemySpeed(float newSpeed) {
    speed = newSpeed;
}

void Enemy::updatePosition(float newX, float newY) {
    x = newX;
    y = newY;
    sprite.setPosition(x, y);
}

int Enemy::getHealth() const {
    return health;
}
