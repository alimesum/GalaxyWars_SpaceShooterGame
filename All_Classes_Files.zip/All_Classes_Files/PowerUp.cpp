#include "PowerUp.h"

using namespace std;
using namespace sf;

PowerUp::PowerUp(float startX, float startY) 
    : GameObject(startX, startY), duration(5.0f) {
    speed = 2.0f;
}

PowerUp::~PowerUp() {}

void PowerUp::update() {
    y += speed;
    sprite.setPosition(x, y);
    
    if (y > 650) {
        active = false;
    }
}

void PowerUp::draw(RenderWindow& window) {
    if (active) {
        window.draw(sprite);
    }
}

FloatRect PowerUp::getBounds() const {
    return sprite.getGlobalBounds();
}

float PowerUp::getDuration() const {
    return duration;
}
