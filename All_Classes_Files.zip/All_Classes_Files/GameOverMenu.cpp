#include "GameOverMenu.h"
#include <iostream>

using namespace sf;
using namespace std;

GameOverMenu::GameOverMenu() {
    // Load background image
    if (!backgroundTex.loadFromFile("assets/b3.jpg")) {
        cerr << "Failed to load game over background image!\n";
    }
    background.setTexture(backgroundTex);
    
    overlay.setSize(Vector2f(1920, 1080));
    overlay.setFillColor(Color(0, 0, 0, 180));
    
    menuBox.setSize(Vector2f(600, 450));
    menuBox.setFillColor(Color(40, 20, 20));
    menuBox.setOutlineThickness(5);
    menuBox.setOutlineColor(Color(200, 0, 0));
    
    titleText.setString("GAME OVER");
    titleText.setCharacterSize(48);
    titleText.setFillColor(Color(255, 50, 50));
    
    gameOverText.setString("Your journey ends here...");
    gameOverText.setCharacterSize(20);
    gameOverText.setFillColor(Color(200, 200, 200));
    
    scoreText.setCharacterSize(24);
    scoreText.setFillColor(Color::White);
    
    remarksText.setString("Better luck next time!");
    remarksText.setCharacterSize(16);
    remarksText.setFillColor(Color(150, 150, 150));
    
    restartButton.setSize(Vector2f(250, 60));
    mainMenuButton.setSize(Vector2f(250, 60));
    
    restartButton.setFillColor(Color(150, 0, 0));
    mainMenuButton.setFillColor(Color(100, 0, 0));
    
    restartButton.setOutlineThickness(3);
    mainMenuButton.setOutlineThickness(3);
    
    restartButton.setOutlineColor(Color(255, 100, 100));
    mainMenuButton.setOutlineColor(Color(255, 100, 100));
    
    restartText.setString("TRY AGAIN");
    mainMenuText.setString("MAIN MENU");
    
    restartText.setCharacterSize(20);
    mainMenuText.setCharacterSize(20);
    
    restartText.setFillColor(Color::White);
    mainMenuText.setFillColor(Color::White);
}

bool GameOverMenu::loadAssets(Font& gameFont) {
    font = gameFont;
    titleText.setFont(font);
    gameOverText.setFont(font);
    scoreText.setFont(font);
    remarksText.setFont(font);
    restartText.setFont(font);
    mainMenuText.setFont(font);
    
    // Load game over music
    if (!gameOverMusic.openFromFile("assets/gameover.ogg")) {
        cerr << "WARNING: Failed to load gameover.ogg\n";
        return false;
    }
    gameOverMusic.setLoop(false);
    gameOverMusic.setVolume(60);
    
    return true;
}

void GameOverMenu::setScoreData(int score, string playerName) {
    // Convert score to string
    string scoreStr = "";
    int temp = score;
    if (temp == 0) scoreStr = "0";
    else {
        while (temp > 0) {
            scoreStr = char('0' + (temp % 10)) + scoreStr;
            temp /= 10;
        }
    }
    
    scoreText.setString("Final Score: " + scoreStr);
    
    // Dynamic remarks based on score
    if (score >= 1500) {
        remarksText.setString("Almost made it!\nYou were so close!\nTry again!");
        remarksText.setFillColor(Color(255, 200, 100));
    } else if (score >= 1000) {
        remarksText.setString("Good effort!\nYou can do better!\nDon't give up!");
        remarksText.setFillColor(Color(200, 200, 100));
    } else if (score >= 500) {
        remarksText.setString("Keep practicing!\nYou're improving!\nTry again!");
        remarksText.setFillColor(Color(150, 150, 150));
    } else if (score >= 200) {
        remarksText.setString("Not bad for a start!\nKeep learning!\nYou'll get there!");
        remarksText.setFillColor(Color(150, 150, 200));
    } else {
        remarksText.setString("Everyone starts somewhere!\nPractice makes perfect!\nTry again!");
        remarksText.setFillColor(Color(150, 150, 150));
    }
}

void GameOverMenu::handleHover(Vector2f mousePos) {
    if (restartButton.getGlobalBounds().contains(mousePos)) {
        restartButton.setFillColor(Color(200, 0, 0));
    } else {
        restartButton.setFillColor(Color(150, 0, 0));
    }
    
    if (mainMenuButton.getGlobalBounds().contains(mousePos)) {
        mainMenuButton.setFillColor(Color(150, 0, 0));
    } else {
        mainMenuButton.setFillColor(Color(100, 0, 0));
    }
}

int GameOverMenu::handleClick(Vector2f mousePos) {
    if (restartButton.getGlobalBounds().contains(mousePos)) {
        return 1;  // Restart
    }
    if (mainMenuButton.getGlobalBounds().contains(mousePos)) {
        return 2;  // Main menu
    }
    return 0;
}

void GameOverMenu::draw(RenderWindow& window) {
    // Get window size
    float screenW = static_cast<float>(window.getSize().x);
    float screenH = static_cast<float>(window.getSize().y);
    
    // Draw full-screen background
    Vector2u texSize = backgroundTex.getSize();
    if (texSize.x > 0 && texSize.y > 0) {
        float scaleX = screenW / texSize.x;
        float scaleY = screenH / texSize.y;
        background.setScale(scaleX, scaleY);
        background.setPosition(0, 0);
        window.draw(background);
    }
    
    // Draw semi-transparent overlay
    overlay.setSize(sf::Vector2f(screenW, screenH));
    overlay.setPosition(0, 0);
    window.draw(overlay);
    
    // Menu box (centered, smaller than screen)
    float boxWidth  = 600.f;
    float boxHeight = 450.f;
    float boxX = (screenW - boxWidth) / 2.f;
    float boxY = (screenH - boxHeight) / 2.f;

    menuBox.setSize(sf::Vector2f(boxWidth, boxHeight));
    menuBox.setPosition(boxX, boxY);
    window.draw(menuBox);

    // Title
    FloatRect titleBounds = titleText.getLocalBounds();
    titleText.setPosition(
        boxX + boxWidth / 2.f - titleBounds.width / 2.f,
        boxY + 30.f
    );
    window.draw(titleText);

    // Game Over message
    FloatRect gameOverBounds = gameOverText.getLocalBounds();
    gameOverText.setPosition(
        boxX + boxWidth / 2.f - gameOverBounds.width / 2.f,
        boxY + 100.f
    );
    window.draw(gameOverText);

    // Score
    FloatRect scoreBounds = scoreText.getLocalBounds();
    scoreText.setPosition(
        boxX + boxWidth / 2.f - scoreBounds.width / 2.f,
        boxY + 160.f
    );
    window.draw(scoreText);

    // Remarks
    FloatRect remarksBounds = remarksText.getLocalBounds();
    remarksText.setPosition(
        boxX + boxWidth / 2.f - remarksBounds.width / 2.f,
        boxY + 230.f
    );
    window.draw(remarksText);

    // Buttons
    float buttonWidth  = 250.f;
    float buttonHeight = 60.f;

    restartButton.setSize(sf::Vector2f(buttonWidth, buttonHeight));
    mainMenuButton.setSize(sf::Vector2f(buttonWidth, buttonHeight));

    restartButton.setPosition(boxX + 50.f, boxY + 350.f);
    mainMenuButton.setPosition(boxX + boxWidth - buttonWidth - 50.f, boxY + 350.f);

    window.draw(restartButton);
    window.draw(mainMenuButton);

    FloatRect restartBounds = restartText.getLocalBounds();
    FloatRect menuBounds    = mainMenuText.getLocalBounds();

    restartText.setPosition(
        restartButton.getPosition().x + buttonWidth / 2.f - restartBounds.width / 2.f,
        restartButton.getPosition().y + buttonHeight / 2.f - restartBounds.height / 2.f - restartBounds.top
    );
    mainMenuText.setPosition(
        mainMenuButton.getPosition().x + buttonWidth / 2.f - menuBounds.width / 2.f,
        mainMenuButton.getPosition().y + buttonHeight / 2.f - menuBounds.height / 2.f - menuBounds.top
    );

    window.draw(restartText);
    window.draw(mainMenuText);
}

void GameOverMenu::playMusic() {
    gameOverMusic.play();
}

void GameOverMenu::stopMusic() {
    gameOverMusic.stop();
}
