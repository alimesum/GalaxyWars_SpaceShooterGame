#ifndef POWERUP_H
#define POWERUP_H

#include "GameObject.h"
#include <SFML/Graphics.hpp>

class PowerUp : public GameObject {
protected:
    sf::Texture texture;  
    sf::Sprite sprite;    
    float duration;
    
public:
    PowerUp(float startX, float startY);
    virtual ~PowerUp();
    
    void update() override;
    void draw(sf::RenderWindow& window) override;
    sf::FloatRect getBounds() const override;
    
    virtual void applyEffect(class Player& player) = 0;
    float getDuration() const;
};

#endif
