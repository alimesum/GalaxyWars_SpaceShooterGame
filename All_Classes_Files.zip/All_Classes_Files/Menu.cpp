#include "Menu.h"
using namespace std;
using namespace sf;

Menu::Menu() {
    playText.setString("START");
    scoresText.setString("HIGH SCORE");
    exitText.setString("EXIT");

    playText.setCharacterSize(22);
    scoresText.setCharacterSize(22);
    exitText.setCharacterSize(22);

    playText.setFillColor(Color::White);
    scoresText.setFillColor(Color::White);
    exitText.setFillColor(Color::White);

    playBox.setSize(Vector2f(275, 55));
    scoresBox.setSize(Vector2f(275, 55));
    exitBox.setSize(Vector2f(275, 55));

    playBox.setFillColor(Color(30, 30, 60));
    scoresBox.setFillColor(Color(30, 30, 60));
    exitBox.setFillColor(Color(30, 30, 60));

    playBox.setOutlineThickness(3);
    scoresBox.setOutlineThickness(3);
    exitBox.setOutlineThickness(3);

    playBox.setOutlineColor(Color(0, 180, 255));
    scoresBox.setOutlineColor(Color(0, 255, 180));
    exitBox.setOutlineColor(Color(255, 80, 80));
}

bool Menu::loadAssets() {
    if (!backgroundTex.loadFromFile("assets/startmenu.png"))
        return false;

    background.setTexture(backgroundTex);

    if (!font.loadFromFile("assets/PressStart2P-Regular.ttf"))
        return false;

    playText.setFont(font);
    scoresText.setFont(font);
    exitText.setFont(font);

    if (!music.openFromFile("assets/Mainmenu.ogg"))
        return false;

    music.setLoop(true);
    music.setVolume(50);
    music.play();
    return true;
}

void Menu::handleHover(Vector2f mousePos) {
    playBox.setFillColor(Color(30, 30, 60));
    scoresBox.setFillColor(Color(30, 30, 60));
    exitBox.setFillColor(Color(30, 30, 60));

    if (playBox.getGlobalBounds().contains(mousePos))
        playBox.setFillColor(Color(0, 120, 220));

    if (scoresBox.getGlobalBounds().contains(mousePos))
        scoresBox.setFillColor(Color(0, 200, 140));

    if (exitBox.getGlobalBounds().contains(mousePos))
        exitBox.setFillColor(Color(220, 60, 60));
}

int Menu::handleClick(Vector2f mousePos) {
    if (playBox.getGlobalBounds().contains(mousePos))
        return 1;
    if (scoresBox.getGlobalBounds().contains(mousePos))
        return 2;
    if (exitBox.getGlobalBounds().contains(mousePos))
        return 3;
    return 0;
}

void Menu::draw(RenderWindow &window) {
    Vector2u winSize = window.getSize();
    float windowWidth = (float)winSize.x;
    float windowHeight = (float)winSize.y;
    
    Vector2u texSize = backgroundTex.getSize();
    float scaleX = windowWidth / texSize.x;
    float scaleY = windowHeight / texSize.y;
    background.setScale(scaleX, scaleY);

    window.draw(background);
    
    // Calculate centered positions
    float buttonWidth = 275.0f;
    float buttonHeight = 55.0f;
    float buttonSpacing = 65.0f;
    
    float centerX = (windowWidth / 2.0f) - (buttonWidth / 2.0f);
    float startY = (windowHeight / 2.0f) - (buttonHeight * 1.5f + buttonSpacing) + 80;
    
    playBox.setPosition(centerX, startY);
    scoresBox.setPosition(centerX, startY + buttonSpacing);
    exitBox.setPosition(centerX, startY + buttonSpacing * 2);
    
    window.draw(playBox);
    window.draw(scoresBox);
    window.draw(exitBox);
    
    FloatRect playTextBounds = playText.getLocalBounds();
    FloatRect scoresTextBounds = scoresText.getLocalBounds();
    FloatRect exitTextBounds = exitText.getLocalBounds();
    
    playText.setPosition(
        centerX + (buttonWidth / 2.0f) - (playTextBounds.width / 2.0f) - playTextBounds.left,
        startY + (buttonHeight / 2.0f) - (playTextBounds.height / 2.0f) - playTextBounds.top
    );
    
    scoresText.setPosition(
        centerX + (buttonWidth / 2.0f) - (scoresTextBounds.width / 2.0f) - scoresTextBounds.left,
        startY + buttonSpacing + (buttonHeight / 2.0f) - (scoresTextBounds.height / 2.0f) - scoresTextBounds.top
    );
    
    exitText.setPosition(
        centerX + (buttonWidth / 2.0f) - (exitTextBounds.width / 2.0f) - exitTextBounds.left,
        startY + buttonSpacing * 2 + (buttonHeight / 2.0f) - (exitTextBounds.height / 2.0f) - exitTextBounds.top
    );
    
    window.draw(playText);
    window.draw(scoresText);
    window.draw(exitText);
}
