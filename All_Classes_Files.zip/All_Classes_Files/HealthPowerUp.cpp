#include "HealthPowerUp.h"
#include <iostream>

using namespace sf;

HealthPowerUp::HealthPowerUp(float x, float y) : PowerUp(x, y) {
    if (!texture.loadFromFile("assets/health.png")) {
        std::cerr << "Failed to load health powerup texture\n";
    }
    sprite.setTexture(texture);
    
    FloatRect bounds = sprite.getLocalBounds();
    sprite.setOrigin(bounds.width / 2, bounds.height / 2);
    sprite.setScale(0.8f, 0.8f);
}

void HealthPowerUp::applyEffect(Player& player) {
    int healAmount = 30;  
    player.heal(healAmount);
}
