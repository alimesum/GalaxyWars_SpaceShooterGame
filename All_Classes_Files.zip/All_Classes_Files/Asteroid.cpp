#include "Asteroid.h"
#include <cstdlib>
#include <iostream>

using namespace std;
using namespace sf;

Asteroid::Asteroid(float startX, float startY, float size) 
    : GameObject(startX, startY), health(20), scoreValue(5) {
    speed = 1.5f + (rand() % 20) / 10.0f;
    rotationSpeed = (rand() % 60 - 30) / 10.0f;
    
    if (!texture.loadFromFile("assets/asteroid.png")) {
        cout << "ERROR: Failed to load asteroid.png\n";
    }
    
    sprite.setTexture(texture);
    sprite.setScale(size / 50.0f, size / 50.0f);
    sprite.setOrigin(25, 25);
    sprite.setPosition(x, y);
}

void Asteroid::update() {
    y += speed;
    sprite.rotate(rotationSpeed);
    sprite.setPosition(x, y);
    
    if (y > 650) {
        active = false;
    }
}

void Asteroid::draw(RenderWindow& window) {
    if (active) {
        window.draw(sprite);
    }
}

FloatRect Asteroid::getBounds() const {
    return sprite.getGlobalBounds();
}

void Asteroid::takeDamage(int damage) {
    health -= damage;
    if (health <= 0) {
        active = false;
    }
}

int Asteroid::getScoreValue() const {
    return scoreValue;
}
