#ifndef VICTORYMENU_H
#define VICTORYMENU_H

#include <SFML/Graphics.hpp>
#include <string>

class VictoryMenu {
private:
    sf::Font font;
    sf::RectangleShape overlay;
    sf::RectangleShape menuBox;
    
    sf::Texture backgroundTex;
    sf::Sprite background;
    
    sf::Text titleText;
    sf::Text congratsText;
    sf::Text scoreText;
    sf::Text highScoreText;
    sf::Text remarksText;
    
    sf::RectangleShape restartButton;
    sf::RectangleShape mainMenuButton;
    
    sf::Text restartText;
    sf::Text mainMenuText;
    
public:
    VictoryMenu();
    bool loadAssets(sf::Font& gameFont);
    void setScoreData(int score, int highScore, std::string playerName);
    void handleHover(sf::Vector2f mousePos);
    int handleClick(sf::Vector2f mousePos);
    void draw(sf::RenderWindow& window);
};

#endif
