#ifndef HIGHSCOREMENU_H
#define HIGHSCOREMENU_H

#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include "ScoreManager.h"

class HighScoreMenu {
private:
    sf::Texture backgroundTex;
    sf::Sprite background;
    sf::Font font;
    sf::Music music;
    
    sf::Text titleText;
    sf::Text scoresText;
    sf::Text noScoresText;
    
    sf::RectangleShape backButton;
    sf::Text backButtonText;
    
    ScoreManager* scoreManager;
    
public:
    HighScoreMenu();
    ~HighScoreMenu();
    
    bool loadAssets();
    void draw(sf::RenderWindow& window);
    bool handleBackClick(sf::Vector2f mousePos);
    void handleHover(sf::Vector2f mousePos);
    void playMusic();
    void stopMusic();
};

#endif
