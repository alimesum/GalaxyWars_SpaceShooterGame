#include <SFML/Graphics.hpp>
#include "Menu.h"
#include "PlayerSetupMenu.h"
#include "GameManager.h"
#include "HighScoreMenu.h"
#include "PauseMenu.h"    
#include "VictoryMenu.h" 
#include "GameOverMenu.h"
#include <iostream>

using namespace sf;
using namespace std;

const int STATE_MAIN_MENU = 0;
const int STATE_PLAYER_SETUP = 1;
const int STATE_PLAYING = 2;
const int STATE_HIGH_SCORES = 3;
const int STATE_PAUSED = 4;      
const int STATE_VICTORY = 5;       
const int STATE_GAME_OVER = 6; 
const int STATE_EXIT = 7; 

int main() {
    VideoMode desktop = VideoMode::getDesktopMode();
    unsigned int windowWidth = 1920;
    unsigned int windowHeight = 1080;
    
    if (desktop.width < windowWidth) windowWidth = desktop.width;
    if (desktop.height < windowHeight) windowHeight = desktop.height;
    
    RenderWindow window(
        VideoMode(windowWidth, windowHeight), 
        "Galaxy Wars",
        Style::Default
    );
    
    window.setFramerateLimit(60);
    bool isFullscreen = false;
    int state = STATE_MAIN_MENU;

    Menu menu;
    if (!menu.loadAssets()) {
        cerr << "Failed to load menu assets!\n";
        return -1;
    }

    PlayerSetupMenu setupMenu;
    if (!setupMenu.loadAssets()) {
        cerr << "Failed to load setup menu assets!\n";
        return -1;
    }

    GameManager* game = new GameManager(windowWidth, windowHeight);
    game->init();

    HighScoreMenu highScoreMenu;
    if (!highScoreMenu.loadAssets()) {
        cerr << "Failed to load high score menu assets!\n";
        return -1;
    }
    
    PauseMenu pauseMenu;
    pauseMenu.loadAssets(game->getFont());
    
    VictoryMenu victoryMenu;
    victoryMenu.loadAssets(game->getFont());
    
    GameOverMenu gameOverMenu;
    gameOverMenu.loadAssets(game->getFont());

    Clock clock;

    while (window.isOpen()) {
        float deltaTime = clock.restart().asSeconds();
        Event event;

        while (window.pollEvent(event)) {
            if (event.type == Event::Closed) {
                window.close();
            }
            
            if (event.type == Event::Resized) {
                FloatRect visibleArea(0, 0, event.size.width, event.size.height);
                window.setView(View(visibleArea));
            }
            
            if (event.type == Event::KeyPressed && event.key.code == Keyboard::F11) {
                window.close();
                
                if (isFullscreen) {
                    window.create(VideoMode(windowWidth, windowHeight), "Galaxy Wars", Style::Default);
                    isFullscreen = false;
                } else {
                    window.create(VideoMode(desktop.width, desktop.height), "Galaxy Wars", Style::Fullscreen);
                    isFullscreen = true;
                }
                
                window.setFramerateLimit(60);
            }

            // ========== MAIN MENU STATE ==========
            if (state == STATE_MAIN_MENU) {
                if (event.type == Event::MouseButtonPressed) {
                    Vector2f mousePos = window.mapPixelToCoords(Mouse::getPosition(window));
                    int choice = menu.handleClick(mousePos);
                    
                    if (choice == 1) {
                        menu.music.stop();
                        setupMenu.reset();
                        setupMenu.playMusic();
                        state = STATE_PLAYER_SETUP;
                    } else if (choice == 2) {
                        menu.music.pause();
                        state = STATE_HIGH_SCORES;
                    } else if (choice == 3) {
                        state = STATE_EXIT;
                    }
                }
            } 
            
            // ========== PLAYER SETUP STATE ==========
            else if (state == STATE_PLAYER_SETUP) {
                if (event.type == Event::TextEntered) {
                    setupMenu.handleTextInput(event.text.unicode);
                }
                
                if (event.type == Event::KeyPressed) {
                    setupMenu.handleKeyPress(event.key.code);
                }
                
                if (event.type == Event::MouseButtonPressed) {
                    Vector2f mousePos = window.mapPixelToCoords(Mouse::getPosition(window));
                    int choice = setupMenu.handleClick(mousePos);
                    
                    if (choice == 1) {
                        setupMenu.stopMusic();
                        
                        string playerName = setupMenu.getPlayerName();
                        int selectedLevel = setupMenu.getSelectedLevel();
                        
                        Vector2u currentSize = window.getSize();
                        delete game;
                        game = new GameManager(currentSize.x, currentSize.y);
                        game->init();
                        pauseMenu.loadAssets(game->getFont());
                        victoryMenu.loadAssets(game->getFont());
                        gameOverMenu.loadAssets(game->getFont());
                        
                        game->setPlayerName(playerName);
                        game->setStartingLevel(selectedLevel);
                        game->restart();
                        
                        state = STATE_PLAYING;
                    } else if (choice == 2) {
                        setupMenu.stopMusic();
                        menu.music.play();
                        state = STATE_MAIN_MENU;
                    }
                }
            }
            
            // ========== PLAYING STATE ==========
            else if (state == STATE_PLAYING) {
                if (event.type == Event::KeyPressed) {
                    if (!game->isVictory() && !game->isGameOver() && 
                        (event.key.code == Keyboard::P || event.key.code == Keyboard::Escape)) {
                        game->togglePause();
                        state = STATE_PAUSED;
                    } else if (!game->isVictory() && !game->isGameOver()) {
                        game->handleInput(event.key.code);
                    }
                }
            }
            
            // ========== PAUSED STATE ==========
            else if (state == STATE_PAUSED) {
                if (event.type == Event::KeyPressed) {
                    if (event.key.code == Keyboard::P || event.key.code == Keyboard::Escape) {
                        game->togglePause();
                        state = STATE_PLAYING;
                    }
                }
                
                if (event.type == Event::MouseButtonPressed) {
                    Vector2f mousePos = window.mapPixelToCoords(Mouse::getPosition(window));
                    int choice = pauseMenu.handleClick(mousePos);
                    
                    if (choice == 1) {
                        game->togglePause();
                        state = STATE_PLAYING;
                    } else if (choice == 2) {
                        game->togglePause();
                        menu.music.play();
                        state = STATE_MAIN_MENU;
                    } else if (choice == 3) {
                        state = STATE_EXIT;
                    }
                }
            }
            
            // ========== VICTORY STATE ==========
            else if (state == STATE_VICTORY) {
                if (event.type == Event::MouseButtonPressed) {
                    Vector2f mousePos = window.mapPixelToCoords(Mouse::getPosition(window));
                    int choice = victoryMenu.handleClick(mousePos);
                    
                    if (choice == 1) {
                        game->restart();
                        state = STATE_PLAYING;
                    } else if (choice == 2) {
                        menu.music.play();
                        state = STATE_MAIN_MENU;
                    }
                }
            }
            
            // ========== GAME OVER STATE ==========
            else if (state == STATE_GAME_OVER) {
                if (event.type == Event::MouseButtonPressed) {
                    Vector2f mousePos = window.mapPixelToCoords(Mouse::getPosition(window));
                    int choice = gameOverMenu.handleClick(mousePos);
                    
                    if (choice == 1) {  // Try Again
                        gameOverMenu.stopMusic();
                        game->restart();
                        state = STATE_PLAYING;
                    } else if (choice == 2) {  // Main Menu
                        gameOverMenu.stopMusic();
                        menu.music.play();
                        state = STATE_MAIN_MENU;
                    }
                }
            }
            
            // ========== HIGH SCORES STATE ==========
            else if (state == STATE_HIGH_SCORES) {
                if (event.type == Event::KeyPressed && event.key.code == Keyboard::Escape) {
                    menu.music.play();
                    state = STATE_MAIN_MENU;
                }
                
                if (event.type == Event::MouseButtonPressed) {
                    Vector2f mousePos = window.mapPixelToCoords(Mouse::getPosition(window));
                    if (highScoreMenu.handleBackClick(mousePos)) {
                        menu.music.play();
                        state = STATE_MAIN_MENU;
                    }
                }
            }
        }

        // ========== UPDATE SECTION ==========
        if (state == STATE_MAIN_MENU) {
            Vector2f mousePos = window.mapPixelToCoords(Mouse::getPosition(window));
            menu.handleHover(mousePos);
        } 
        else if (state == STATE_PLAYER_SETUP) {
            setupMenu.update(deltaTime);
            Vector2f mousePos = window.mapPixelToCoords(Mouse::getPosition(window));
            setupMenu.handleHover(mousePos);
        }
        else if (state == STATE_PLAYING) {
            if (!game->isVictory() && !game->isGameOver()) {
                if (Keyboard::isKeyPressed(Keyboard::Up)) game->handleInput(Keyboard::Up);
                if (Keyboard::isKeyPressed(Keyboard::Down)) game->handleInput(Keyboard::Down);
                if (Keyboard::isKeyPressed(Keyboard::Left)) game->handleInput(Keyboard::Left);
                if (Keyboard::isKeyPressed(Keyboard::Right)) game->handleInput(Keyboard::Right);
                if (Keyboard::isKeyPressed(Keyboard::Space)) game->handleInput(Keyboard::Space);
            }

            game->update();
            
            // Check for victory
            if (game->isVictory() && state != STATE_VICTORY) {
                string playerName = setupMenu.getPlayerName();
                victoryMenu.setScoreData(game->getFinalScore(), 1500, playerName);
                state = STATE_VICTORY;
            }
            
            // Check for game over
            if (game->isGameOver() && !game->isVictory() && state != STATE_GAME_OVER) {
                string playerName = setupMenu.getPlayerName();
                gameOverMenu.setScoreData(game->getFinalScore(), playerName);
                gameOverMenu.playMusic();
                state = STATE_GAME_OVER;
            }
        }
        else if (state == STATE_PAUSED) {
            Vector2f mousePos = window.mapPixelToCoords(Mouse::getPosition(window));
            pauseMenu.handleHover(mousePos);
        }
        else if (state == STATE_VICTORY) {
            Vector2f mousePos = window.mapPixelToCoords(Mouse::getPosition(window));
            victoryMenu.handleHover(mousePos);
        }
        else if (state == STATE_GAME_OVER) {
            Vector2f mousePos = window.mapPixelToCoords(Mouse::getPosition(window));
            gameOverMenu.handleHover(mousePos);
        }
        else if (state == STATE_HIGH_SCORES) {
            Vector2f mousePos = window.mapPixelToCoords(Mouse::getPosition(window));
            highScoreMenu.handleHover(mousePos);
        }

        // ========== DRAW SECTION ==========
        window.clear();

        if (state == STATE_MAIN_MENU) {
            menu.draw(window);
        } 
        else if (state == STATE_PLAYER_SETUP) {
            setupMenu.draw(window);
        }
        else if (state == STATE_PLAYING) {
            game->render(window);
        }
        else if (state == STATE_PAUSED) {
            game->render(window);
            pauseMenu.draw(window);
        }
        else if (state == STATE_VICTORY) {
            game->render(window);
            victoryMenu.draw(window);
        }
        else if (state == STATE_GAME_OVER) {
            game->render(window);
            gameOverMenu.draw(window);
        }
        else if (state == STATE_HIGH_SCORES) {
            highScoreMenu.draw(window);
        }
        else if (state == STATE_EXIT) {
            window.close();
        }

        window.display();
    }

    delete game;
    return 0;
}
