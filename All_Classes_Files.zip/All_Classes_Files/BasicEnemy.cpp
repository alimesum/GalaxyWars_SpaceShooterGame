#include "BasicEnemy.h"
#include <iostream>

using namespace std;
using namespace sf;

BasicEnemy::BasicEnemy(float startX, float startY) 
    : Enemy(startX, startY, 30, 10) {
    if (!texture.loadFromFile("assets/enemyB.png")) {
        cout << "ERROR: Failed to load enemyB.png - File missing!\n";
    }
    texture.setSmooth(false);
    
    sprite.setTexture(texture);
    
    FloatRect bounds = sprite.getLocalBounds();
    float targetSize = 60.0f;
    float scaleX = targetSize / bounds.width;
    float scaleY = targetSize / bounds.height;
    sprite.setScale(scaleX, scaleY);
    
    sprite.setOrigin(bounds.width / 2.0f, bounds.height / 2.0f);
    sprite.setPosition(startX, startY);
}

void BasicEnemy::move() {
    y += speed;
    sprite.setPosition(x, y);
}

void BasicEnemy::update() {
    if (active) {
        move();
        
        // Deactivate if off screen
        if (y > 650) {
            active = false;
        }
    }
}
