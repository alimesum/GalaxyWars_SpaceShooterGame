#include "ResourcePowerUp.h"
#include <iostream>

using namespace std;
using namespace sf;

ResourcePowerUp::ResourcePowerUp(float startX, float startY) 
    : PowerUp(startX, startY), resourceBoost(5, 5, 5) {
    
    if (!texture.loadFromFile("assets/resource.png")) {
        cout << "Failed to load resource powerup texture\n";
    }
    sprite.setTexture(texture);
    sprite.setPosition(x, y);
    sprite.setScale(0.5f, 0.5f);
}

void ResourcePowerUp::applyEffect(Player& player) {
    player.addResources(resourceBoost);
    player.addScore(20);
}

Resource ResourcePowerUp::getResourceBoost() const {
    return resourceBoost;
}
