#include "Resource.h"
#include <sstream>

using namespace std;

Resource::Resource(int c, int m, int e) 
    : crystals(c), metal(m), energy(e) {}

Resource Resource::operator+(const Resource& other) const {
    return Resource(crystals + other.crystals, 
                   metal + other.metal, 
                   energy + other.energy);
}

Resource Resource::operator-(const Resource& other) const {
    return Resource(crystals - other.crystals, 
                   metal - other.metal, 
                   energy - other.energy);
}

Resource& Resource::operator+=(const Resource& other) {
    crystals += other.crystals;
    metal += other.metal;
    energy += other.energy;
    return *this;
}

bool Resource::operator==(const Resource& other) const {
    return crystals == other.crystals && 
           metal == other.metal && 
           energy == other.energy;
}

bool Resource::operator>(const Resource& other) const {
    return getTotalValue() > other.getTotalValue();
}

int Resource::getCrystals() const {
    return crystals;
}

int Resource::getMetal() const {
    return metal;
}

int Resource::getEnergy() const {
    return energy;
}

int Resource::getTotalValue() const {
    return crystals + metal + energy;
}

string Resource::toString() const {
    // Manual string building without stringstream
    string result = "C:";
    
    // Convert crystals to string
    int temp = crystals;
    char buffer[20];
    int index = 0;
    if (temp == 0) {
        buffer[index++] = '0';
    } else {
        while (temp > 0) {
            buffer[index++] = '0' + (temp % 10);
            temp /= 10;
        }
        // Reverse
        for (int i = 0; i < index / 2; i++) {
            char t = buffer[i];
            buffer[i] = buffer[index - 1 - i];
            buffer[index - 1 - i] = t;
        }
    }
    buffer[index] = '\0';
    result += buffer;
    
    result += " M:";
    
    // Convert metal
    temp = metal;
    index = 0;
    if (temp == 0) {
        buffer[index++] = '0';
    } else {
        while (temp > 0) {
            buffer[index++] = '0' + (temp % 10);
            temp /= 10;
        }
        for (int i = 0; i < index / 2; i++) {
            char t = buffer[i];
            buffer[i] = buffer[index - 1 - i];
            buffer[index - 1 - i] = t;
        }
    }
    buffer[index] = '\0';
    result += buffer;
    
    result += " E:";
    
    // Convert energy
    temp = energy;
    index = 0;
    if (temp == 0) {
        buffer[index++] = '0';
    } else {
        while (temp > 0) {
            buffer[index++] = '0' + (temp % 10);
            temp /= 10;
        }
        for (int i = 0; i < index / 2; i++) {
            char t = buffer[i];
            buffer[i] = buffer[index - 1 - i];
            buffer[index - 1 - i] = t;
        }
    }
    buffer[index] = '\0';
    result += buffer;
    
    return result;
}
