#include "GameException.h"

using namespace std;

GameException::GameException(const string& msg, int code) 
    : message(msg), errorCode(code) {}

const char* GameException::what() const {
    return message.c_str();
}

string GameException::getMessage() const {
    return message;
}

int GameException::getErrorCode() const {
    return errorCode;
}

FileLoadException::FileLoadException(const string& filename) 
    : GameException("Failed to load file: " + filename, 1001) {}

InvalidOperationException::InvalidOperationException(const string& operation) 
    : GameException("Invalid operation: " + operation, 2001) {}
