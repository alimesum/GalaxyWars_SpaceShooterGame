#ifndef PROJECTILE_H
#define PROJECTILE_H

#include "GameObject.h"
#include <SFML/Graphics.hpp>

class Projectile : public GameObject {
private:
    sf::Texture texture;  
    sf::Sprite sprite;    
    int damage;
    bool fromPlayer;
    
public:
    Projectile(float startX, float startY, bool isPlayerProjectile, int dmg = 10);
    
    void update() override;
    void draw(sf::RenderWindow& window) override;
    sf::FloatRect getBounds() const override;
    
    int getDamage() const;
    bool isFromPlayer() const;
};

#endif
