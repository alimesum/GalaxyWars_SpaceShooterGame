#ifndef GAMEOVERMENU_H
#define GAMEOVERMENU_H

#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <string>

class GameOverMenu {
private:
    sf::Font font;
    sf::Texture backgroundTex;
    sf::Sprite background;
    sf::RectangleShape overlay;
    sf::RectangleShape menuBox;
    
    sf::Text titleText;
    sf::Text gameOverText;
    sf::Text scoreText;
    sf::Text remarksText;
    
    sf::RectangleShape restartButton;
    sf::RectangleShape mainMenuButton;
    
    sf::Text restartText;
    sf::Text mainMenuText;
    
public:
    sf::Music gameOverMusic; 
    GameOverMenu();
    bool loadAssets(sf::Font& gameFont);
    void setScoreData(int score, std::string playerName);
    void handleHover(sf::Vector2f mousePos);
    int handleClick(sf::Vector2f mousePos);
    void draw(sf::RenderWindow& window);
    void playMusic();
    void stopMusic();
};

#endif
