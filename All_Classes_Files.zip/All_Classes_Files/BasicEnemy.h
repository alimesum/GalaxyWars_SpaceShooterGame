#ifndef BASICENEMY_H
#define BASICENEMY_H

#include "Enemy.h"

class BasicEnemy : public Enemy {
public:
    BasicEnemy(float startX, float startY);
    
    void move() override;
    void update() override;  
};

#endif
