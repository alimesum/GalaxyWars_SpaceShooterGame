#ifndef GAMEOBJECT_H
#define GAMEOBJECT_H

#include <SFML/Graphics.hpp>

class GameObject {
protected:
    float x, y;
    float speed;
    bool active;
    
public:
    GameObject(float startX = 0, float startY = 0);
    virtual ~GameObject();
    
    virtual void update() = 0;
    virtual void draw(sf::RenderWindow& window) = 0;
    virtual sf::FloatRect getBounds() const = 0;
    
    bool isActive() const;
    void setActive(bool status);
    float getX() const;
    float getY() const;
    float getSpeed() const;  
    void setPosition(float newX, float newY);
};

#endif
