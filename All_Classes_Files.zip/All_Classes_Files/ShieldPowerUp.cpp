#include "ShieldPowerUp.h"
#include <iostream>

using namespace sf;

ShieldPowerUp::ShieldPowerUp(float x, float y) : PowerUp(x, y) {
    if (!texture.loadFromFile("assets/shield.png")) {
        std::cerr << "Failed to load shield powerup texture\n";
    }
    sprite.setTexture(texture);
    
    FloatRect bounds = sprite.getLocalBounds();
    sprite.setOrigin(bounds.width / 2, bounds.height / 2);
    sprite.setScale(0.8f, 0.8f);
}

void ShieldPowerUp::applyEffect(Player& player) {
    float shieldDuration = 8.0f;  
    player.activateShield(shieldDuration);
}
