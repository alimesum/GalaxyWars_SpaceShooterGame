#ifndef PLAYER_H
#define PLAYER_H

#include "GameObject.h"
#include "Resource.h"
#include <SFML/Graphics.hpp>

class Player : public GameObject {
private:
    sf::Texture texture;
    sf::Texture shieldTexture;
    sf::Sprite sprite;
    int health;
    int maxHealth;
    int score;
    float fireRate;
    float fireTimer;
    bool shieldActive;
    float shieldTimer;
    int weaponLevel;
    Resource collectedResources;
    
    float maxX;
    float maxY;
    
    static int totalPlayers;
    
public:
    Player(float startX, float startY);
    ~Player();
    
    void update() override;
    void draw(sf::RenderWindow& window) override;
    sf::FloatRect getBounds() const override;
    
    void move(float dx, float dy);
    bool canFire();
    void resetFireTimer();
    void takeDamage(int damage);
    void heal(int amount);
    void addScore(int points);
    void activateShield(float duration);
    void setFireRate(float rate);
    
    void addResources(const Resource& res);
    Resource getResources() const;
    void upgradeWeapon();
    int getWeaponLevel() const;
    int getProjectileDamage() const;
    
    void setBoundaries(float maxWidth, float maxHeight);
    
    int getHealth() const;
    int getScore() const;
    bool hasShield() const;
    sf::Vector2f getPosition() const;
    
    static int getTotalPlayers();
    
    friend void displayPlayerStats(const Player& player);
};

void displayPlayerStats(const Player& player);

#endif
