#include "HighScoreMenu.h"
#include <iostream>

using namespace std;
using namespace sf;

HighScoreMenu::HighScoreMenu() {
    scoreManager = new ScoreManager("highscores.txt");
    
    titleText.setString("HIGH SCORES");
    titleText.setCharacterSize(32);
    titleText.setFillColor(Color::Yellow);
    
    noScoresText.setString("No high scores yet!\nPlay the game to set a record.");
    noScoresText.setCharacterSize(18);
    noScoresText.setFillColor(Color::White);
    
    scoresText.setCharacterSize(16);
    scoresText.setFillColor(Color::White);
    
    backButton.setSize(Vector2f(150, 50));
    backButton.setFillColor(Color(150, 0, 0));
    backButton.setOutlineThickness(3);
    backButton.setOutlineColor(Color::White);
    
    backButtonText.setString("BACK");
    backButtonText.setCharacterSize(18);
    backButtonText.setFillColor(Color::White);
}

HighScoreMenu::~HighScoreMenu() {
    if (scoreManager) delete scoreManager;
}

bool HighScoreMenu::loadAssets() {
    if (!backgroundTex.loadFromFile("assets/b3.jpg")) {
        cerr << "ERROR: Failed to load background for high scores\n";
        return false;
    }
    background.setTexture(backgroundTex);
    
    if (!font.loadFromFile("assets/PressStart2P-Regular.ttf")) {
        cerr << "ERROR: Failed to load font for high scores\n";
        return false;
    }
    
    titleText.setFont(font);
    scoresText.setFont(font);
    noScoresText.setFont(font);
    backButtonText.setFont(font);
    
    if (!music.openFromFile("assets/highscore.ogg")) {
        cerr << "WARNING: Failed to load music for high scores\n";
    } else {
        music.setLoop(true);
        music.setVolume(40);
    }
    
    return true;
}

void HighScoreMenu::playMusic() {
    music.play();
}

void HighScoreMenu::stopMusic() {
    music.stop();
}

void HighScoreMenu::handleHover(Vector2f mousePos) {
    if (backButton.getGlobalBounds().contains(mousePos)) {
        backButton.setFillColor(Color(200, 0, 0));
    } else {
        backButton.setFillColor(Color(150, 0, 0));
    }
}

bool HighScoreMenu::handleBackClick(Vector2f mousePos) {
    return backButton.getGlobalBounds().contains(mousePos);
}


void HighScoreMenu::draw(RenderWindow& window) {
    Vector2u winSize = window.getSize();
    float windowWidth = (float)winSize.x;
    float windowHeight = (float)winSize.y;
    
    Vector2u texSize = backgroundTex.getSize();
    float scaleX = windowWidth / texSize.x;
    float scaleY = windowHeight / texSize.y;
    background.setScale(scaleX, scaleY);
    window.draw(background);
    
    FloatRect titleBounds = titleText.getLocalBounds();
    titleText.setPosition(windowWidth / 2 - titleBounds.width / 2, 50);
    window.draw(titleText);
    
    // Get high scores using arrays
    ScoreEntry topScores[10];
    int scoreCount = 0;
    scoreManager->getTopScores(topScores, 10, scoreCount);
    
    if (scoreCount == 0) {
        FloatRect noScoresBounds = noScoresText.getLocalBounds();
        noScoresText.setPosition(
            windowWidth / 2 - noScoresBounds.width / 2,
            windowHeight / 2 - 50
        );
        window.draw(noScoresText);
    } else {
        string scoresDisplay = "";
        
        for (int i = 0; i < scoreCount; i++) {
            // Convert rank to string
            string rankStr = "";
            int rank = i + 1;
            if (rank == 0) rankStr = "0";
            else {
                while (rank > 0) {
                    rankStr = char('0' + (rank % 10)) + rankStr;
                    rank /= 10;
                }
            }
            
            // Convert score to string
            string scoreStr = "";
            int score = topScores[i].score;
            if (score == 0) scoreStr = "0";
            else {
                while (score > 0) {
                    scoreStr = char('0' + (score % 10)) + scoreStr;
                    score /= 10;
                }
            }
            
            // Convert time to string
            string timeStr = "";
            int time = topScores[i].playTime;
            if (time == 0) timeStr = "0";
            else {
                while (time > 0) {
                    timeStr = char('0' + (time % 10)) + timeStr;
                    time /= 10;
                }
            }
            
            // Get player name and convert underscores back to spaces
            string displayName = topScores[i].playerName;
            for (int j = 0; j < (int)displayName.length(); j++) {
                if (displayName[j] == '_') {
                    displayName[j] = ' ';
                }
            }
            
            // Format display with proper name
            scoresDisplay += rankStr + ". ";
            scoresDisplay += displayName;
            
            // Add spacing to align scores (adjust based on name length)
            int spacesNeeded = 20 - displayName.length();
            if (spacesNeeded < 2) spacesNeeded = 2;  // Minimum 2 spaces
            for (int j = 0; j < spacesNeeded; j++) {
                scoresDisplay += " ";
            }
            
            scoresDisplay += scoreStr + " pts";
            scoresDisplay += " - " + timeStr + "s\n";
        }
        
        scoresText.setString(scoresDisplay);
        
        FloatRect scoresBounds = scoresText.getLocalBounds();
        scoresText.setPosition(
            windowWidth / 2 - scoresBounds.width / 2,
            150
        );
        window.draw(scoresText);
        cout << endl;
    }
    
    backButton.setPosition(windowWidth / 2 - 75, windowHeight - 100);
    window.draw(backButton);
    
    FloatRect backBounds = backButtonText.getLocalBounds();
    backButtonText.setPosition(
        windowWidth / 2 - backBounds.width / 2,
        windowHeight - 90
    );
    window.draw(backButtonText);
}
