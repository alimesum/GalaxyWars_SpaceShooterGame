#ifndef RESOURCE_H
#define RESOURCE_H

#include <string>

class Resource {
private:
    int crystals;
    int metal;
    int energy;
    
public:
    Resource(int c = 0, int m = 0, int e = 0);
    
    // Operator overloading
    Resource operator+(const Resource& other) const;
    Resource operator-(const Resource& other) const;
    Resource& operator+=(const Resource& other);
    bool operator==(const Resource& other) const;
    bool operator>(const Resource& other) const;
    
    // Getters
    int getCrystals() const;
    int getMetal() const;
    int getEnergy() const;
    int getTotalValue() const;
    
    // Display
    std::string toString() const;
};

#endif
