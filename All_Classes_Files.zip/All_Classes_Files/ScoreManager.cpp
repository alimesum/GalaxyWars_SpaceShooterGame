#include "ScoreManager.h"
#include <fstream>
#include <iostream>

using namespace std;

ScoreManager::ScoreManager(string file) : filename(file), scoreCount(0) {
    loadScores();
}

void ScoreManager::loadScores() {
    scoreCount = 0;
    ifstream file(filename.c_str());
    
    if (file.is_open()) {
        string line;
        
        // Read line by line
        while (getline(file, line) && scoreCount < 10) {
            // Parse: "PlayerName Score PlayTime"
            // Find first space (after name)
            int firstSpace = -1;
            for (int i = line.length() - 1; i >= 0; i--) {
                if (line[i] == ' ') {
                    firstSpace = i;
                    break;
                }
            }
            
            if (firstSpace == -1) continue;  // Invalid line
            
            // Find second space (before play time)
            int secondSpace = -1;
            for (int i = firstSpace - 1; i >= 0; i--) {
                if (line[i] == ' ') {
                    secondSpace = i;
                    break;
                }
            }
            
            if (secondSpace == -1) continue;  // Invalid line
            
            // Extract parts
            string name = "";
            string scoreStr = "";
            string timeStr = "";
            
            // Get name (0 to secondSpace)
            for (int i = 0; i < secondSpace; i++) {
                name += line[i];
            }
            
            // Get score (secondSpace+1 to firstSpace)
            for (int i = secondSpace + 1; i < firstSpace; i++) {
                scoreStr += line[i];
            }
            
            // Get time (firstSpace+1 to end)
            for (int i = firstSpace + 1; i < (int)line.length(); i++) {
                timeStr += line[i];
            }
            
            // Convert strings to numbers
            int score = 0;
            for (int i = 0; i < (int)scoreStr.length(); i++) {
                if (scoreStr[i] >= '0' && scoreStr[i] <= '9') {
                    score = score * 10 + (scoreStr[i] - '0');
                }
            }
            
            int playTime = 0;
            for (int i = 0; i < (int)timeStr.length(); i++) {
                if (timeStr[i] >= '0' && timeStr[i] <= '9') {
                    playTime = playTime * 10 + (timeStr[i] - '0');
                }
            }
            
            // Store score entry
            if (name.length() > 0) {
                scores[scoreCount] = ScoreEntry(name, score, playTime);
                scoreCount++;
            }
        }
        
        file.close();
    }
}

void ScoreManager::saveScores() {
    ofstream file(filename.c_str());
    
    if (file.is_open()) {
        for (int i = 0; i < scoreCount; i++) {
            // Save as: "PlayerName Score PlayTime"
            file << scores[i].playerName << " " 
                 << scores[i].score << " " 
                 << scores[i].playTime << "\n";
        }
        
        file.close();
    }
}

void ScoreManager::addScore(string playerName, int score, int playTime) {
    // Fix empty names
    if (playerName.length() == 0 || playerName == " ") {
        playerName = "Anonymous";
    }
    
    for (int i = 0; i < (int)playerName.length(); i++) {
        if (playerName[i] == ' ') {
            playerName[i] = '_';
        }
    }
    
    if (scoreCount < 10) {
        scores[scoreCount] = ScoreEntry(playerName, score, playTime);
        scoreCount++;
    } else {
        // Replace lowest score if new score is higher
        int lowestIndex = 0;
        for (int i = 1; i < 10; i++) {
            if (scores[i].score < scores[lowestIndex].score) {
                lowestIndex = i;
            }
        }
        
        if (score > scores[lowestIndex].score) {
            scores[lowestIndex] = ScoreEntry(playerName, score, playTime);
        }
    }
    
    // Sort by score (highest first) - Bubble sort
    for (int i = 0; i < scoreCount - 1; i++) {
        for (int j = 0; j < scoreCount - i - 1; j++) {
            if (scores[j].score < scores[j + 1].score) {
                ScoreEntry temp = scores[j];
                scores[j] = scores[j + 1];
                scores[j + 1] = temp;
            }
        }
    }
    
    saveScores();
}

void ScoreManager::getTopScores(ScoreEntry* outScores, int maxCount, int& outCount) {
    outCount = 0;
    int limit = maxCount < scoreCount ? maxCount : scoreCount;
    
    for (int i = 0; i < limit; i++) {
        outScores[i] = scores[i];
        outCount++;
    }
}

int ScoreManager::getHighScore() {
    if (scoreCount == 0) {
        return 0;
    }
    return scores[0].score;
}

int ScoreManager::getScoreCount() const {
    return scoreCount;
}
