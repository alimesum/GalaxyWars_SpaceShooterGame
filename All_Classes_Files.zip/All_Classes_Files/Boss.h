#ifndef BOSS_H
#define BOSS_H

#include "Enemy.h"
#include <SFML/Graphics.hpp>

class Boss : public Enemy {
private:
    float moveDirection;
    float fireTimer;
    float fireRate;
    int phase;
    float phaseTimer;
    float windowWidth;
    
public:
    Boss(float startX, float startY, float winWidth);
    
    void move() override;
    void update() override;  
    bool canFire();
    void resetFireTimer();
    int getPhase() const;
};

#endif
