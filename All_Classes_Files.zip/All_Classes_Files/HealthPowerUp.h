#ifndef HEALTHPOWERUP_H
#define HEALTHPOWERUP_H

#include "PowerUp.h"
#include "Player.h"

class HealthPowerUp : public PowerUp {
public:
    HealthPowerUp(float startX, float startY);
    void applyEffect(Player& player) override;
};

#endif
