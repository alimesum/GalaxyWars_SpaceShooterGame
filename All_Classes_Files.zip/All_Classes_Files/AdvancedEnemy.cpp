#include "AdvancedEnemy.h"
#include <iostream>
#include <cmath>

using namespace std;
using namespace sf;

AdvancedEnemy::AdvancedEnemy(float startX, float startY) 
    : BasicEnemy(startX, startY), angle(0), amplitude(2.0f) {
    speed = 3.0f;
    health = 50;
    scoreValue = 20;
    
    if (!texture.loadFromFile("assets/enemyAD.png")) {
        cout << "ERROR: Failed to load enemyAD.png - File missing!\n";
    }
    texture.setSmooth(false);
    
    sprite.setTexture(texture);
    
    FloatRect bounds = sprite.getLocalBounds();
    float targetSize = 70.0f;
    float scaleX = targetSize / bounds.width;
    float scaleY = targetSize / bounds.height;
    sprite.setScale(scaleX, scaleY);
    
    sprite.setOrigin(bounds.width / 2.0f, bounds.height / 2.0f);
    sprite.setPosition(startX, startY);
}

void AdvancedEnemy::move() {
    y += speed;
    x += amplitude * sin(angle);
    angle += 0.1f;
    sprite.setPosition(x, y);
}

void AdvancedEnemy::update() {
    if (active) {
        move();
        
        // Deactivate if off screen
        if (y > 650) {
            active = false;
        }
    }
}
