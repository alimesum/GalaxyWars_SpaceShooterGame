#include "GameObject.h"

using namespace std;
using namespace sf;

GameObject::GameObject(float startX, float startY) 
    : x(startX), y(startY), speed(0), active(true) {}

GameObject::~GameObject() {}

bool GameObject::isActive() const {
    return active;
}

void GameObject::setActive(bool status) {
    active = status;
}

float GameObject::getX() const {
    return x;
}

float GameObject::getY() const {
    return y;
}

float GameObject::getSpeed() const { 
    return speed;
}

void GameObject::setPosition(float newX, float newY) {
    x = newX;
    y = newY;
}
