#include "PlayerSetupMenu.h"
#include <iostream>

using namespace std;
using namespace sf;

PlayerSetupMenu::PlayerSetupMenu() 
    : playerName(""), nameActive(false), selectedLevel(1), 
      blinkTimer(0), cursorVisible(true) {
    
    // Title
    titleText.setString("PLAYER SETUP");
    titleText.setCharacterSize(28);
    titleText.setFillColor(Color::Cyan);
    
    // Name prompt
    namePromptText.setString("Enter Your Name:");
    namePromptText.setCharacterSize(18);
    namePromptText.setFillColor(Color::White);
    
    // Name input display
    nameInputText.setString("");
    nameInputText.setCharacterSize(20);
    nameInputText.setFillColor(Color::White);
    
    // Name input box
    nameInputBox.setSize(Vector2f(400, 50));
    nameInputBox.setFillColor(Color(40, 40, 60));
    nameInputBox.setOutlineThickness(3);
    nameInputBox.setOutlineColor(Color(100, 100, 150));
    
    // Level prompt
    levelPromptText.setString("Select Starting Level:");
    levelPromptText.setCharacterSize(18);
    levelPromptText.setFillColor(Color::White);
    
    // Level boxes
    level1Box.setSize(Vector2f(120, 60));
    level2Box.setSize(Vector2f(120, 60));
    level3Box.setSize(Vector2f(120, 60));
    
    level1Box.setFillColor(Color(0, 150, 0));
    level2Box.setFillColor(Color(40, 40, 60));
    level3Box.setFillColor(Color(40, 40, 60));
    
    level1Box.setOutlineThickness(3);
    level2Box.setOutlineThickness(3);
    level3Box.setOutlineThickness(3);
    
    level1Box.setOutlineColor(Color::Yellow);
    level2Box.setOutlineColor(Color(100, 100, 150));
    level3Box.setOutlineColor(Color(100, 100, 150));
    
    // Level texts
    level1Text.setString("LEVEL 1");
    level2Text.setString("LEVEL 2");
    level3Text.setString("LEVEL 3");
    
    level1Text.setCharacterSize(16);
    level2Text.setCharacterSize(16);
    level3Text.setCharacterSize(16);
    
    level1Text.setFillColor(Color::White);
    level2Text.setFillColor(Color::White);
    level3Text.setFillColor(Color::White);
    
    // Start button
    startButton.setSize(Vector2f(200, 50));
    startButton.setFillColor(Color(0, 150, 0));
    startButton.setOutlineThickness(3);
    startButton.setOutlineColor(Color::White);
    
    startButtonText.setString("START GAME");
    startButtonText.setCharacterSize(18);
    startButtonText.setFillColor(Color::White);
    
    // Back button
    backButton.setSize(Vector2f(150, 40));
    backButton.setFillColor(Color(150, 0, 0));
    backButton.setOutlineThickness(2);
    backButton.setOutlineColor(Color::White);
    
    backButtonText.setString("BACK");
    backButtonText.setCharacterSize(16);
    backButtonText.setFillColor(Color::White);
}




bool PlayerSetupMenu::loadAssets() {
    // Load background image
    if (!backgroundTex.loadFromFile("assets/b3.jpg")) {
        cerr << "WARNING: Failed to load setupmenu.png, trying b3.jpg\n";
        if (!backgroundTex.loadFromFile("assets/b3.jpg")) {
            cerr << "ERROR: Failed to load background image\n";
            return false;
        }
    }
    
    background.setTexture(backgroundTex);
    
    if (!font.loadFromFile("assets/PressStart2P-Regular.ttf")) {
        cerr << "ERROR: Failed to load font\n";
        return false;
    }
    
    titleText.setFont(font);
    namePromptText.setFont(font);
    nameInputText.setFont(font);
    levelPromptText.setFont(font);
    level1Text.setFont(font);
    level2Text.setFont(font);
    level3Text.setFont(font);
    startButtonText.setFont(font);
    backButtonText.setFont(font);
    
    if (!music.openFromFile("assets/Mainmenu.ogg")) {
        cerr << "WARNING: Failed to load setupmenu.ogg, trying Mainmenu.ogg\n";
        if (!music.openFromFile("assets/highscore.ogg")) {
            cerr << "ERROR: Failed to load setup menu music\n";
            return false;
        }
    }
    
    music.setLoop(true);
    music.setVolume(50);
    
    return true;
}

void PlayerSetupMenu::playMusic() {
    music.play();
}

void PlayerSetupMenu::stopMusic() {
    music.stop();
}


void PlayerSetupMenu::handleHover(Vector2f mousePos) {
    // Hover over name input
    if (nameInputBox.getGlobalBounds().contains(mousePos)) {
        nameInputBox.setOutlineColor(Color::Cyan);
    } else {
        nameInputBox.setOutlineColor(Color(100, 100, 150));
    }
    
    // Hover over level boxes
    if (level1Box.getGlobalBounds().contains(mousePos) && selectedLevel != 1) {
        level1Box.setFillColor(Color(0, 120, 0));
    } else if (selectedLevel != 1) {
        level1Box.setFillColor(Color(40, 40, 60));
    }
    
    if (level2Box.getGlobalBounds().contains(mousePos) && selectedLevel != 2) {
        level2Box.setFillColor(Color(0, 120, 0));
    } else if (selectedLevel != 2) {
        level2Box.setFillColor(Color(40, 40, 60));
    }
    
    if (level3Box.getGlobalBounds().contains(mousePos) && selectedLevel != 3) {
        level3Box.setFillColor(Color(0, 120, 0));
    } else if (selectedLevel != 3) {
        level3Box.setFillColor(Color(40, 40, 60));
    }
    
    // Hover over start button
    if (startButton.getGlobalBounds().contains(mousePos)) {
        startButton.setFillColor(Color(0, 200, 0));
    } else {
        startButton.setFillColor(Color(0, 150, 0));
    }
    
    // Hover over back button
    if (backButton.getGlobalBounds().contains(mousePos)) {
        backButton.setFillColor(Color(200, 0, 0));
    } else {
        backButton.setFillColor(Color(150, 0, 0));
    }
}

int PlayerSetupMenu::handleClick(Vector2f mousePos) {
    // Click on name input box
    if (nameInputBox.getGlobalBounds().contains(mousePos)) {
        nameActive = true;
        nameInputBox.setOutlineColor(Color::Yellow);
        return 0;
    } else {
        nameActive = false;
    }
    
    // Click on level 1
    if (level1Box.getGlobalBounds().contains(mousePos)) {
        selectedLevel = 1;
        level1Box.setFillColor(Color(0, 150, 0));
        level1Box.setOutlineColor(Color::Yellow);
        
        level2Box.setFillColor(Color(40, 40, 60));
        level2Box.setOutlineColor(Color(100, 100, 150));
        
        level3Box.setFillColor(Color(40, 40, 60));
        level3Box.setOutlineColor(Color(100, 100, 150));
        return 0;
    }
    
    // Click on level 2
    if (level2Box.getGlobalBounds().contains(mousePos)) {
        selectedLevel = 2;
        level2Box.setFillColor(Color(0, 150, 0));
        level2Box.setOutlineColor(Color::Yellow);
        
        level1Box.setFillColor(Color(40, 40, 60));
        level1Box.setOutlineColor(Color(100, 100, 150));
        
        level3Box.setFillColor(Color(40, 40, 60));
        level3Box.setOutlineColor(Color(100, 100, 150));
        return 0;
    }
    
    // Click on level 3
    if (level3Box.getGlobalBounds().contains(mousePos)) {
        selectedLevel = 3;
        level3Box.setFillColor(Color(0, 150, 0));
        level3Box.setOutlineColor(Color::Yellow);
        
        level1Box.setFillColor(Color(40, 40, 60));
        level1Box.setOutlineColor(Color(100, 100, 150));
        
        level2Box.setFillColor(Color(40, 40, 60));
        level2Box.setOutlineColor(Color(100, 100, 150));
        return 0;
    }
    
    // Click on start button
    if (startButton.getGlobalBounds().contains(mousePos)) {
        if (playerName.length() > 0) {
            return 1;  // Start game
        }
        return 0;
    }
    
    // Click on back button
    if (backButton.getGlobalBounds().contains(mousePos)) {
        return 2;  // Back to main menu
    }
    
    return 0;
}

void PlayerSetupMenu::handleTextInput(Uint32 unicode) {
    if (!nameActive) return;
    
    // Handle backspace
    if (unicode == 8) {
        if (playerName.length() > 0) {
            playerName.pop_back();
        }
    }
    // Handle printable characters
    else if (unicode >= 32 && unicode < 127 && playerName.length() < 15) {
        playerName += static_cast<char>(unicode);
    }
    
    nameInputText.setString(playerName);
}

void PlayerSetupMenu::handleKeyPress(Keyboard::Key key) {
    // Handle Enter key to start game
    if (key == Keyboard::Enter && playerName.length() > 0) {
        // Trigger start
    }
}

void PlayerSetupMenu::update(float deltaTime) {
    // Update cursor blink
    blinkTimer += deltaTime;
    if (blinkTimer > 0.5f) {
        cursorVisible = !cursorVisible;
        blinkTimer = 0;
    }
}

void PlayerSetupMenu::draw(RenderWindow& window) {
    Vector2u winSize = window.getSize();
    float windowWidth = (float)winSize.x;
    float windowHeight = (float)winSize.y;
    
    // Scale background
    Vector2u texSize = backgroundTex.getSize();
    float scaleX = windowWidth / texSize.x;
    float scaleY = windowHeight / texSize.y;
    background.setScale(scaleX, scaleY);
    window.draw(background);
    
    // Position title
    titleText.setPosition(windowWidth / 2 - 180, 50);
    window.draw(titleText);
    
    // Position name prompt
    namePromptText.setPosition(windowWidth / 2 - 200, 150);
    window.draw(namePromptText);
    
    // Position name input box
    nameInputBox.setPosition(windowWidth / 2 - 200, 190);
    window.draw(nameInputBox);
    
    // Position name text with cursor
    string displayName = playerName;
    if (nameActive && cursorVisible) {
        displayName += "|";
    }
    nameInputText.setString(displayName);
    nameInputText.setPosition(windowWidth / 2 - 190, 200);
    window.draw(nameInputText);
    
    // Position level prompt
    levelPromptText.setPosition(windowWidth / 2 - 240, 280);
    window.draw(levelPromptText);
    
    // Position level boxes
    float levelY = 330;
    level1Box.setPosition(windowWidth / 2 - 210, levelY);
    level2Box.setPosition(windowWidth / 2 - 60, levelY);
    level3Box.setPosition(windowWidth / 2 + 90, levelY);
    
    window.draw(level1Box);
    window.draw(level2Box);
    window.draw(level3Box);
    
    // Position level texts (centered in boxes)
    FloatRect l1Bounds = level1Text.getLocalBounds();
    FloatRect l2Bounds = level2Text.getLocalBounds();
    FloatRect l3Bounds = level3Text.getLocalBounds();
    
    level1Text.setPosition(
        windowWidth / 2 - 210 + 60 - l1Bounds.width / 2,
        levelY + 20
    );
    level2Text.setPosition(
        windowWidth / 2 - 60 + 60 - l2Bounds.width / 2,
        levelY + 20
    );
    level3Text.setPosition(
        windowWidth / 2 + 90 + 60 - l3Bounds.width / 2,
        levelY + 20
    );
    
    window.draw(level1Text);
    window.draw(level2Text);
    window.draw(level3Text);
    
    // Position start button
    startButton.setPosition(windowWidth / 2 - 100, 450);
    window.draw(startButton);
    
    FloatRect startBounds = startButtonText.getLocalBounds();
    startButtonText.setPosition(
        windowWidth / 2 - startBounds.width / 2,
        460
    );
    window.draw(startButtonText);
    
    // Position back button
    backButton.setPosition(50, windowHeight - 70);
    window.draw(backButton);
    
    FloatRect backBounds = backButtonText.getLocalBounds();
    backButtonText.setPosition(
        50 + 75 - backBounds.width / 2,
        windowHeight - 60
    );
    window.draw(backButtonText);
}

string PlayerSetupMenu::getPlayerName() const {
    // Return default if empty
    if (playerName.length() == 0 || playerName == " ") {
        return "Player";
    }
    return playerName;
}


int PlayerSetupMenu::getSelectedLevel() const {
    return selectedLevel;
}

void PlayerSetupMenu::reset() {
    playerName = "";
    selectedLevel = 1;
    nameActive = false;
    
    nameInputText.setString("");
    
    level1Box.setFillColor(Color(0, 150, 0));
    level1Box.setOutlineColor(Color::Yellow);
    
    level2Box.setFillColor(Color(40, 40, 60));
    level2Box.setOutlineColor(Color(100, 100, 150));
    
    level3Box.setFillColor(Color(40, 40, 60));
    level3Box.setOutlineColor(Color(100, 100, 150));
}
