#ifndef ASTEROID_H
#define ASTEROID_H

#include "GameObject.h"
#include <SFML/Graphics.hpp>

class Asteroid : public GameObject {
private:
    sf::Texture texture;   
    sf::Sprite sprite;     
    int health;
    int scoreValue;
    float rotationSpeed;
    
public:
    Asteroid(float startX, float startY, float size);
    
    void update() override;
    void draw(sf::RenderWindow& window) override;
    sf::FloatRect getBounds() const override;
    
    void takeDamage(int damage);
    int getScoreValue() const;
};

#endif
