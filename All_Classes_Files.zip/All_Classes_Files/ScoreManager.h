#ifndef SCOREMANAGER_H
#define SCOREMANAGER_H

#include <string>

struct ScoreEntry {
    std::string playerName;
    int score;
    int playTime;
    
    ScoreEntry() : playerName(""), score(0), playTime(0) {}
    ScoreEntry(std::string name, int s, int time)
        : playerName(name), score(s), playTime(time) {}
};

class ScoreManager {
private:
    std::string filename;
    ScoreEntry scores[10];  // Fixed array - max 10 scores
    int scoreCount;          // Track number of scores
    
    void loadScores();
    void saveScores();
    
public:
    ScoreManager(std::string file);
    
    void addScore(std::string playerName, int score, int playTime);
    void getTopScores(ScoreEntry* outScores, int maxCount, int& outCount);
    int getHighScore();
    int getScoreCount() const;
};

#endif
