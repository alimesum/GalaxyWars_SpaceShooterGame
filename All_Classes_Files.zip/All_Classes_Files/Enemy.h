#ifndef ENEMY_H
#define ENEMY_H

#include "GameObject.h"
#include <SFML/Graphics.hpp>

class Enemy : public GameObject {
protected:
    sf::Texture texture;
    sf::Sprite sprite;
    int health;
    int scoreValue;
    int maxHealth;
    
public:
    Enemy(float startX, float startY, int hp, int score);
    virtual ~Enemy();
    
    virtual void move() = 0;
    void draw(sf::RenderWindow& window) override;
    sf::FloatRect getBounds() const override;
    
    void takeDamage(int damage);
    int getScoreValue() const;
    void setTarget(float playerX);
    
    int getHealth() const;
    float getX() const;
    float getY() const;
    float getSpeed() const;
    void setEnemySpeed(float newSpeed);
    void updatePosition(float newX, float newY);
};

#endif
