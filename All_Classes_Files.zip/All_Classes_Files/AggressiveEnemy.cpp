#include "AggressiveEnemy.h"
#include <cmath>
#include <iostream>

using namespace std;
using namespace sf;

AggressiveEnemy::AggressiveEnemy(float startX, float startY) 
    : Enemy(startX, startY, 70, 30), targetX(startX), chaseSpeed(1.5f) {
    setEnemySpeed(2.5f);
    
    if (!texture.loadFromFile("assets/enemyAG.png")) {
        cout << "ERROR: Failed to load enemyAG.png - File missing!\n";
    }
    texture.setSmooth(false);
    
    sprite.setTexture(texture);
    
    FloatRect bounds = sprite.getLocalBounds();
    float targetSize = 85.0f;
    float scaleX = targetSize / bounds.width;
    float scaleY = targetSize / bounds.height;
    sprite.setScale(scaleX, scaleY);
    
    sprite.setOrigin(bounds.width / 2.0f, bounds.height / 2.0f);
    sprite.setPosition(startX, startY);
}

void AggressiveEnemy::move() {
    float currentX = getX();
    float currentY = getY();
    float currentSpeed = getSpeed();
    
    currentY += currentSpeed;
    
    if (currentX < targetX) {
        currentX += chaseSpeed;
    } else if (currentX > targetX) {
        currentX -= chaseSpeed;
    }
    
    updatePosition(currentX, currentY);
}

void AggressiveEnemy::update() {
    if (active) {
        move();
        
        // Deactivate if off screen
        if (getY() > 650) {
            active = false;
        }
    }
}

void AggressiveEnemy::setTarget(float playerX) {
    targetX = playerX;
}
