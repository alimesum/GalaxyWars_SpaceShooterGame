#ifndef MENU_H
#define MENU_H

#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>

class Menu {
public:
    sf::Texture backgroundTex;
    sf::Sprite background;

    sf::Font font;

    sf::Text playText;
    sf::Text scoresText;
    sf::Text exitText;

    sf::RectangleShape playBox;
    sf::RectangleShape scoresBox;
    sf::RectangleShape exitBox;

    sf::Music music;

    Menu();
    bool loadAssets();
    void draw(sf::RenderWindow& window);
    void handleHover(sf::Vector2f mousePos);
    int handleClick(sf::Vector2f mousePos);
};

#endif
