#include "Projectile.h"
#include <iostream>

using namespace std;
using namespace sf;

Projectile::Projectile(float startX, float startY, bool isPlayerProjectile, int dmg) 
    : GameObject(startX, startY), damage(dmg), fromPlayer(isPlayerProjectile) {
    speed = 10.0f;
    
    if (fromPlayer) {
        if (!texture.loadFromFile("assets/bullet2.png")) {
            cerr << "ERROR: Failed to load projectile_player.png\n";
        }
    } else {
        if (!texture.loadFromFile("assets/bullet1.png")) {
            cerr << "ERROR: Failed to load projectile_enemy.png\n";
        }
    }
    
    texture.setSmooth(false); // Remove blur
    
    sprite.setTexture(texture);
    
    FloatRect bounds = sprite.getLocalBounds();
    sprite.setOrigin(bounds.width / 2.0f, bounds.height / 2.0f);
    
    // Scale to display size (20x20 for bullets)
    float targetSize = 20.0f; // Projectile displays at 20x20
    sprite.setScale(targetSize / bounds.width, targetSize / bounds.height);
    
    sprite.setPosition(x, y);
}

void Projectile::update() {
    if (fromPlayer) {
        y -= speed;
    } else {
        y += speed;
    }
    
    sprite.setPosition(x, y);
    
    if (y < -10 || y > 1100) {
        active = false;
    }
}

void Projectile::draw(RenderWindow& window) {
    if (active) {
        window.draw(sprite);
    }
}

FloatRect Projectile::getBounds() const {
    return sprite.getGlobalBounds();
}

int Projectile::getDamage() const {
    return damage;
}

bool Projectile::isFromPlayer() const {
    return fromPlayer;
}
