#ifndef ADVANCEDENEMY_H
#define ADVANCEDENEMY_H

#include "BasicEnemy.h"

//Advanced Enemy inherit the basic enemy publically
class AdvancedEnemy : public BasicEnemy {
private:
    float angle;
    float amplitude;
    
public:
    AdvancedEnemy(float startX, float startY);
    
    void move() override;
    void update() override; 
};

#endif
