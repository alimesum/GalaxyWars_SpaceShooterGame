#include "Boss.h"
#include <cmath>
#include <iostream>

using namespace std;
using namespace sf;

Boss::Boss(float startX, float startY, float winWidth) 
    : Enemy(startX, startY, 500, 100), moveDirection(1.0f), 
      fireTimer(0), fireRate(1.0f), phase(1), phaseTimer(0), windowWidth(winWidth) {
    speed = 2.0f;
    
    if (!texture.loadFromFile("assets/boss.png")) {
        cerr << "ERROR: Failed to load boss.png\n";
    }
    texture.setSmooth(false);
    
    sprite.setTexture(texture);
    
    FloatRect bounds = sprite.getLocalBounds();
    float targetSize = 200.0f;
    float scaleX = targetSize / bounds.width;
    float scaleY = targetSize / bounds.height;
    sprite.setScale(scaleX, scaleY);
    
    // Set origin to center
    sprite.setOrigin(bounds.width / 2.0f, bounds.height / 2.0f);
    sprite.setPosition(startX, startY);
}

void Boss::move() {
    // Boss moves side to side at top of screen
    x += speed * moveDirection;
    
    sf::FloatRect bounds = sprite.getGlobalBounds();
    float halfWidth = bounds.width / 2;

    // Bounce at screen edges dynamically
    if (x > windowWidth - halfWidth - 50 || x < halfWidth + 50) {
        moveDirection *= -1;
    }
    
    // Slowly move down until reaching position
    if (y < 150) {
        y += 0.3f;
    }
    
    // Update sprite position
    sprite.setPosition(x, y);
}

void Boss::update() {
    if (!active) return;
    
    // Move the boss
    move();
    
    // Update fire timer
    if (fireTimer > 0) {
        fireTimer -= 0.016f;
    }
    
    // Update phase based on health percentage
    float healthPercent = (float)health / (float)maxHealth;
    if (healthPercent > 0.66f) {
        phase = 1;  // Phase 1: Triple shot
    } else if (healthPercent > 0.33f) {
        phase = 2;  // Phase 2: Five-way spread
    } else {
        phase = 3;  // Phase 3: Rapid fire barrage
    }
    
    // Fire rate based on phase
    if (phase == 1) {
        fireRate = 1.0f;  // Shoots every 1 second
    } else if (phase == 2) {
        fireRate = 0.8f;  // Shoots every 0.8 seconds
    } else if (phase == 3) {
        fireRate = 0.6f;  // Shoots every 0.6 seconds (faster)
    }
}

bool Boss::canFire() {
    return fireTimer <= 0;
}

void Boss::resetFireTimer() {
    fireTimer = fireRate;
}

int Boss::getPhase() const {
    return phase;
}
