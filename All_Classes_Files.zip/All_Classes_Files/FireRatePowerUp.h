#ifndef FIRERATEPOWERUP_H
#define FIRERATEPOWERUP_H

#include "PowerUp.h"
#include "Player.h"

class FireRatePowerUp : public PowerUp {
public:
    FireRatePowerUp(float startX, float startY);
    void applyEffect(Player& player) override;
};

#endif
