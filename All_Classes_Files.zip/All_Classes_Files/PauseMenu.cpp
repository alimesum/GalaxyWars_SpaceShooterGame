#include "PauseMenu.h"
#include <iostream>

using namespace std;
using namespace sf;

PauseMenu::PauseMenu() {
    overlay.setSize(Vector2f(1920, 1080));
    overlay.setFillColor(Color(0, 0, 0, 180));
    
    menuBox.setSize(Vector2f(400, 350));
    menuBox.setFillColor(Color(30, 30, 50));
    menuBox.setOutlineThickness(5);
    menuBox.setOutlineColor(Color(100, 100, 150));
    
    titleText.setString("PAUSED");
    titleText.setCharacterSize(36);
    titleText.setFillColor(Color::Yellow);
    
    resumeButton.setSize(Vector2f(300, 60));
    mainMenuButton.setSize(Vector2f(300, 60));
    exitButton.setSize(Vector2f(300, 60));
    
    resumeButton.setFillColor(Color(0, 150, 0));
    mainMenuButton.setFillColor(Color(0, 100, 200));
    exitButton.setFillColor(Color(200, 0, 0));
    
    resumeButton.setOutlineThickness(3);
    mainMenuButton.setOutlineThickness(3);
    exitButton.setOutlineThickness(3);
    
    resumeButton.setOutlineColor(Color::White);
    mainMenuButton.setOutlineColor(Color::White);
    exitButton.setOutlineColor(Color::White);
    
    resumeText.setString("RESUME");
    mainMenuText.setString("MAIN MENU");
    exitText.setString("EXIT GAME");
    
    resumeText.setCharacterSize(20);
    mainMenuText.setCharacterSize(20);
    exitText.setCharacterSize(20);
    
    resumeText.setFillColor(Color::White);
    mainMenuText.setFillColor(Color::White);
    exitText.setFillColor(Color::White);
}

bool PauseMenu::loadAssets(Font& gameFont) {
    font = gameFont;
    titleText.setFont(font);
    resumeText.setFont(font);
    mainMenuText.setFont(font);
    exitText.setFont(font);


    if (!backgroundTex.loadFromFile("assets/b1.jpg")) {
        cout << "WARNING: Failed to load setupmenu.png, trying b1.jpg\n";
        if (!backgroundTex.loadFromFile("assets/b3.jpg")) {
            cout << "ERROR: Failed to load background image\n";
            return false;
        }
    }

        background.setTexture(backgroundTex);

    return true;
}

void PauseMenu::handleHover(Vector2f mousePos) {
    if (resumeButton.getGlobalBounds().contains(mousePos)) {
        resumeButton.setFillColor(Color(0, 200, 0));
    } else {
        resumeButton.setFillColor(Color(0, 150, 0));
    }
    
    if (mainMenuButton.getGlobalBounds().contains(mousePos)) {
        mainMenuButton.setFillColor(Color(0, 150, 255));
    } else {
        mainMenuButton.setFillColor(Color(0, 100, 200));
    }
    
    if (exitButton.getGlobalBounds().contains(mousePos)) {
        exitButton.setFillColor(Color(255, 0, 0));
    } else {
        exitButton.setFillColor(Color(200, 0, 0));
    }
}

int PauseMenu::handleClick(Vector2f mousePos) {
    if (resumeButton.getGlobalBounds().contains(mousePos)) {
        return 1;
    }
    if (mainMenuButton.getGlobalBounds().contains(mousePos)) {
        return 2;
    }
    if (exitButton.getGlobalBounds().contains(mousePos)) {
        return 3;
    }
    return 0;
}

void PauseMenu::draw(RenderWindow& window) {
    Vector2u winSize = window.getSize();
    float windowWidth = (float)winSize.x;
    float windowHeight = (float)winSize.y;
    
    overlay.setSize(Vector2f(windowWidth, windowHeight));
    window.draw(overlay);
    
    float boxX = (windowWidth / 2.0f) - 200;
    float boxY = (windowHeight / 2.0f) - 175;
    menuBox.setPosition(boxX, boxY);
    window.draw(menuBox);
    
    FloatRect titleBounds = titleText.getLocalBounds();
    titleText.setPosition(boxX + 200 - titleBounds.width / 2, boxY + 30);
    window.draw(titleText);
    
    resumeButton.setPosition(boxX + 50, boxY + 100);
    mainMenuButton.setPosition(boxX + 50, boxY + 180);
    exitButton.setPosition(boxX + 50, boxY + 260);
    
    window.draw(resumeButton);
    window.draw(mainMenuButton);
    window.draw(exitButton);
    
    FloatRect resumeBounds = resumeText.getLocalBounds();
    FloatRect menuBounds = mainMenuText.getLocalBounds();
    FloatRect exitBounds = exitText.getLocalBounds();
    
    resumeText.setPosition(boxX + 200 - resumeBounds.width / 2, boxY + 115);
    mainMenuText.setPosition(boxX + 200 - menuBounds.width / 2, boxY + 195);
    exitText.setPosition(boxX + 200 - exitBounds.width / 2, boxY + 275);
    
    window.draw(resumeText);
    window.draw(mainMenuText);
    window.draw(exitText);
}
