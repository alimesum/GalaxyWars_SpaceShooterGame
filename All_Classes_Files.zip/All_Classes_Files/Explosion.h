#ifndef EXPLOSION_H
#define EXPLOSION_H

#include "GameObject.h"
#include <SFML/Graphics.hpp>

class Explosion : public GameObject {
private:
    sf::Texture texture;
    sf::Sprite sprite;
    float lifetime;
    float maxLifetime;
    float scale;
    
public:
    Explosion(float startX, float startY);
    
    void update() override;
    void draw(sf::RenderWindow& window) override;
    sf::FloatRect getBounds() const override;
    
    bool isFinished() const;
};

#endif
