#ifndef RESOURCEPOWERUP_H
#define RESOURCEPOWERUP_H

#include "PowerUp.h"
#include "Player.h"
#include "Resource.h"

class ResourcePowerUp : public PowerUp {
private:
    Resource resourceBoost;
    
public:
    ResourcePowerUp(float startX, float startY);
    void applyEffect(Player& player) override;
    Resource getResourceBoost() const;
};

#endif
