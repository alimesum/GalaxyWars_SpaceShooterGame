#ifndef AGGRESSIVEENEMY_H
#define AGGRESSIVEENEMY_H

#include "Enemy.h"

class AggressiveEnemy : public Enemy {
private:
    float targetX;
    float chaseSpeed;
    
public:
    AggressiveEnemy(float startX, float startY);
    
    void move() override;
    void update() override;
    void setTarget(float playerX);
};

#endif
