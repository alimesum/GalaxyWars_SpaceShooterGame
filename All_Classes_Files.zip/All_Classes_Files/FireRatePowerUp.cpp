#include "FireRatePowerUp.h"
#include <iostream>

using namespace std;
using namespace sf;

FireRatePowerUp::FireRatePowerUp(float startX, float startY) 
    : PowerUp(startX, startY) {
    duration = 10.0f;
    
    if (!texture.loadFromFile("assets/bulletD.png")) {
        cerr << "ERROR: Failed to load powerup_firerate.png\n";
    }
    sprite.setTexture(texture);
    sprite.setPosition(x, y);
    sprite.setScale(0.5f, 0.5f);
}

void FireRatePowerUp::applyEffect(Player& player) {
    player.setFireRate(0.1f);
}
