#ifndef PLAYERSETUPMENU_H
#define PLAYERSETUPMENU_H

#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp> 
#include <string>

class PlayerSetupMenu {
private:
    sf::Texture backgroundTex;
    sf::Sprite background;
    sf::Font font;
    sf::Music music;  
    
    // Title
    sf::Text titleText;
    
    // Name input
    sf::Text namePromptText;
    sf::Text nameInputText;
    sf::RectangleShape nameInputBox;
    std::string playerName;
    bool nameActive;
    
    // Level selection
    sf::Text levelPromptText;
    sf::RectangleShape level1Box;
    sf::RectangleShape level2Box;
    sf::RectangleShape level3Box;
    sf::Text level1Text;
    sf::Text level2Text;
    sf::Text level3Text;
    int selectedLevel;
    
    // Start button
    sf::RectangleShape startButton;
    sf::Text startButtonText;
    
    // Back button
    sf::RectangleShape backButton;
    sf::Text backButtonText;
    
    // Cursor blink
    float blinkTimer;
    bool cursorVisible;
    
public:
    PlayerSetupMenu();
    bool loadAssets();
    void handleHover(sf::Vector2f mousePos);
    int handleClick(sf::Vector2f mousePos);
    void handleTextInput(sf::Uint32 unicode);
    void handleKeyPress(sf::Keyboard::Key key);
    void update(float deltaTime);
    void draw(sf::RenderWindow& window);
    
    std::string getPlayerName() const;
    int getSelectedLevel() const;
    void reset();
    void stopMusic();  
    void playMusic();  
};

#endif
