#include "GameManager.h"
#include "GameException.h"
#include <iostream>
#include <cstdlib>
#include <cmath>
#include <string>

using namespace std;
using namespace sf;

// Helper function to convert int to string manually
string intToString(int number) {
    if (number == 0) return "0";
    
    bool isNegative = false;
    if (number < 0) {
        isNegative = true;
        number = -number;
    }
    
    char buffer[20];
    int index = 0;
    
    while (number > 0) {
        buffer[index++] = '0' + (number % 10);
        number /= 10;
    }
    
    if (isNegative) {
        buffer[index++] = '-';
    }
    
    buffer[index] = '\0';
    
    for (int i = 0; i < index / 2; i++) {
        char temp = buffer[i];
        buffer[i] = buffer[index - 1 - i];
        buffer[index - 1 - i] = temp;
    }
    
    return string(buffer);
}

GameManager::GameManager(float winWidth, float winHeight) 
    : maxEnemies(20), maxProjectiles(50), maxAsteroids(15), maxPowerups(5),
      maxExplosions(30),
      enemyCount(0), projectileCount(0), asteroidCount(0), powerupCount(0),
      explosionCount(0),
      currentLevel(1), waveNumber(1), spawnTimer(0), powerupTimer(0),
      paused(false), gameOver(false), victory(false),
      levelTransition(false), bossWarning(false),
      transitionTimer(0), blinkTimer(0), bossSpawnTimer(0), textVisible(true),
      bossSpawned(false),
      windowWidth(winWidth), windowHeight(winHeight), previousLevel(1),
      playerName("Player"), startingLevel(1) {
    
    player = new Player(windowWidth / 2 - 25, windowHeight - 100);
    player->setBoundaries(windowWidth, windowHeight);
    
    enemies = new Enemy*[maxEnemies];
    projectiles = new Projectile*[maxProjectiles];
    asteroids = new Asteroid*[maxAsteroids];
    powerups = new PowerUp*[maxPowerups];
    explosions = new Explosion*[maxExplosions];
    boss = nullptr;
    
    for (int i = 0; i < maxEnemies; i++) enemies[i] = nullptr;
    for (int i = 0; i < maxProjectiles; i++) projectiles[i] = nullptr;
    for (int i = 0; i < maxAsteroids; i++) asteroids[i] = nullptr;
    for (int i = 0; i < maxPowerups; i++) powerups[i] = nullptr;
    for (int i = 0; i < maxExplosions; i++) explosions[i] = nullptr;
    
    scoreManager = new ScoreManager("highscores.txt");
    
    collectedResources = Resource(0, 0, 0);
    startTime = clock();
}

GameManager::~GameManager() {
    delete player;

    if (boss) delete boss;
    
    for (int i = 0; i < maxEnemies; i++) {
        if (enemies[i]) delete enemies[i];
    }
    delete[] enemies;
    
    for (int i = 0; i < maxProjectiles; i++) {
        if (projectiles[i]) delete projectiles[i];
    }
    delete[] projectiles;
    
    for (int i = 0; i < maxAsteroids; i++) {
        if (asteroids[i]) delete asteroids[i];
    }
    delete[] asteroids;
    
    for (int i = 0; i < maxPowerups; i++) {
        if (powerups[i]) delete powerups[i];
    }
    delete[] powerups;
    
    for (int i = 0; i < maxExplosions; i++) {
        if (explosions[i]) delete explosions[i];
    }
    delete[] explosions;
    
    if (scoreManager) delete scoreManager;
}

void GameManager::setPlayerName(string name) {
    playerName = name;
}

void GameManager::setStartingLevel(int level) {
    startingLevel = level;
    currentLevel = level;
    previousLevel = level;
}

float GameManager::getWindowWidth() const {
    return windowWidth;
}

float GameManager::getWindowHeight() const {
    return windowHeight;
}

void GameManager::playLevelMusic(int level) {
    level1Music.stop();
    level2Music.stop();
    level3Music.stop();
    
    if (level == 1) {
        level1Music.play();
    } else if (level == 2) {
        level2Music.play();
    } else if (level == 3) {
        level3Music.play();
    }
}

void GameManager::createExplosion(float x, float y) {
    for (int i = 0; i < maxExplosions; i++) {
        if (!explosions[i] || !explosions[i]->isActive()) {
            if (explosions[i]) delete explosions[i];
            
            explosions[i] = new Explosion(x, y);
            explosionSound.play();
            break;
        }
    }
}

void GameManager::init() {
    // Load background
    if (!backgroundTex.loadFromFile("assets/fightb.png")) {
        cerr << "ERROR: Failed to load fightb.png\n";
    }
    background.setTexture(backgroundTex);
    
    // Load font
    if (!font.loadFromFile("assets/PressStart2P-Regular.ttf")) {
        cerr << "ERROR: Failed to load font file\n";
    }
    
    scoreText.setFont(font);
    scoreText.setCharacterSize(16);
    scoreText.setFillColor(Color::White);
    scoreText.setPosition(10, 10);
    
    healthText.setFont(font);
    healthText.setCharacterSize(16);
    healthText.setFillColor(Color::Green);
    healthText.setPosition(10, 35);
    
    levelText.setFont(font);
    levelText.setCharacterSize(16);
    levelText.setFillColor(Color::Yellow);
    levelText.setPosition(10, 60);
    
    gameOverText.setFont(font);
    gameOverText.setCharacterSize(32);
    gameOverText.setFillColor(Color::Red);
    gameOverText.setString("GAME OVER");
    gameOverText.setPosition(windowWidth / 2 - 200, windowHeight / 2);
    
    pauseText.setFont(font);
    pauseText.setCharacterSize(24);
    pauseText.setFillColor(Color::Cyan);
    pauseText.setString("PAUSED");
    pauseText.setPosition(windowWidth / 2 - 100, windowHeight / 2);
    
    transitionText.setFont(font);
    transitionText.setCharacterSize(28);
    transitionText.setFillColor(Color::Yellow);
    transitionText.setPosition(windowWidth / 2 - 250, windowHeight / 2 - 50);
    
    bossWarningText.setFont(font);
    bossWarningText.setCharacterSize(24);
    bossWarningText.setFillColor(Color::Red);
    bossWarningText.setString("WARNING: BOSS INCOMING!");
    bossWarningText.setPosition(windowWidth / 2 - 280, windowHeight / 2);
    
    bossHealthText.setFont(font);
    bossHealthText.setCharacterSize(16);
    bossHealthText.setFillColor(Color::Red);
    bossHealthText.setPosition(windowWidth - 250, 10);
    
    // Load music
    if (!level1Music.openFromFile("assets/lvl1.ogg")) {
        cerr << "ERROR: Failed to load level1.ogg\n";
    }
    level1Music.setLoop(true);
    level1Music.setVolume(50);
    
    if (!level2Music.openFromFile("assets/lvl2.ogg")) {
        cerr << "ERROR: Failed to load level2.ogg\n";
    }
    level2Music.setLoop(true);
    level2Music.setVolume(50);
    
    if (!level3Music.openFromFile("assets/pause.ogg")) {
        cerr << "ERROR: Failed to load level3.ogg\n";
    }
    level3Music.setLoop(true);
    level3Music.setVolume(50);
    
    if (!gameOverMusic.openFromFile("assets/gameover.ogg")) {
        cerr << "ERROR: Failed to load gameover.ogg\n";
    }
    gameOverMusic.setLoop(false);
    gameOverMusic.setVolume(70);
    
    if (!bossMusic.openFromFile("assets/boss.ogg")) {
        cerr << "ERROR: Failed to load boss.ogg\n";
    }
    bossMusic.setLoop(true);
    bossMusic.setVolume(60);
    
    // Load sound effects
    if (!bossWarningBuffer.loadFromFile("assets/hit.wav")) {
        cerr << "ERROR: Failed to load boss_warning.wav\n";
    }
    bossWarningSound.setBuffer(bossWarningBuffer);
    bossWarningSound.setVolume(70);
    
    if (!shootBuffer.loadFromFile("assets/firebullet.wav")) {
        cerr << "ERROR: Failed to load shoot.wav\n";
    }
    shootSound.setBuffer(shootBuffer);
    shootSound.setVolume(30);
    
    if (!powerupBuffer.loadFromFile("assets/powerup.wav")) {
        cerr << "ERROR: Failed to load powerup.wav\n";
    }
    powerupSound.setBuffer(powerupBuffer);
    powerupSound.setVolume(50);
    
    if (!explosionBuffer.loadFromFile("assets/hit.wav")) {
        cerr << "ERROR: Failed to load explosion.wav\n";
    }
    explosionSound.setBuffer(explosionBuffer);
    explosionSound.setVolume(50);
    
    if (!enemyDeathBuffer.loadFromFile("assets/hit.wav")) {
        cerr << "ERROR: Failed to load enemy_death.wav\n";
    }
    enemyDeathSound.setBuffer(enemyDeathBuffer);
    enemyDeathSound.setVolume(50);
    
    if (!gameOverBuffer.loadFromFile("assets/hit.wav")) {
        cerr << "ERROR: Failed to load gameover_sound.wav\n";
    }
    gameOverSound.setBuffer(gameOverBuffer);
    gameOverSound.setVolume(70);
    
    // Start level music
    playLevelMusic(startingLevel);
}

void GameManager::update() {
    // Handle level transition or boss warning
    if (levelTransition || bossWarning) {
        transitionTimer -= 0.016f;
        blinkTimer += 0.016f;
        
        if (blinkTimer > 0.3f) {
            textVisible = !textVisible;
            blinkTimer = 0;
        }
        
        if (transitionTimer <= 0) {
            if (levelTransition) {
                levelTransition = false;
                previousLevel = currentLevel;
            }
            if (bossWarning) {
                bossWarning = false;
                spawnBoss();
            }
        }
        return;
    }
    
    // Stop all gameplay if paused, game over, or victory
    if (paused || gameOver || victory) return;
    
    // Update player
    player->update();
    
    // Update boss
    if (boss && boss->isActive()) {
        boss->update();
        bossFire();
    }
    
    // Update all enemies
    for (int i = 0; i < maxEnemies; i++) {
        if (enemies[i] && enemies[i]->isActive()) {
            enemies[i]->update();
        }
    }
    
    // Update all projectiles
    for (int i = 0; i < maxProjectiles; i++) {
        if (projectiles[i] && projectiles[i]->isActive()) {
            projectiles[i]->update();
        }
    }
    
    // Update all asteroids
    for (int i = 0; i < maxAsteroids; i++) {
        if (asteroids[i] && asteroids[i]->isActive()) {
            asteroids[i]->update();
        }
    }
    
    // Update all powerups
    for (int i = 0; i < maxPowerups; i++) {
        if (powerups[i] && powerups[i]->isActive()) {
            powerups[i]->update();
        }
    }
    
    // Update all explosions
    for (int i = 0; i < maxExplosions; i++) {
        if (explosions[i] && explosions[i]->isActive()) {
            explosions[i]->update();
        }
    }
    
    // Update timers
    spawnTimer += 0.016f;
    powerupTimer += 0.016f;
    
    // Spawn enemies (not during boss fight)
    if (!boss || !boss->isActive()) {
        if (spawnTimer > 2.0f / currentLevel) {
            spawnEnemies();
            spawnTimer = 0;
        }
    }
    
    // Faster powerup spawning in level 3 and during boss
    float powerupSpawnTime = 15.0f;
    
    if (boss && boss->isActive()) {
        powerupSpawnTime = 8.0f;
    } else if (currentLevel == 3) {
        powerupSpawnTime = 10.0f;
    } else if (currentLevel == 2) {
        powerupSpawnTime = 12.0f;
    }
    
    if (powerupTimer > powerupSpawnTime) {
        spawnPowerup();
        powerupTimer = 0;
    }
    
    // Check collisions
    checkCollisions();
    
    // Clean up inactive objects
    cleanupInactive();
    
    // Update level progression
    updateLevel();
    
    // Check level change and play appropriate music
    if (currentLevel != previousLevel) {
        playLevelMusic(currentLevel);
        previousLevel = currentLevel;
    }
    
    // Check for player death
    if (player->getHealth() <= 0 && !gameOver && !victory) {
        gameOver = true;
        victory = false;
        
        // Stop all music
        level1Music.stop();
        level2Music.stop();
        level3Music.stop();
        bossMusic.stop();
        
        // Play game over sound effect
        gameOverSound.play();
        
        // Save score
        if (scoreManager) {
            int playTime = (clock() - startTime) / CLOCKS_PER_SEC;
            scoreManager->addScore(playerName, player->getScore(), playTime);
        }
    }
}

void GameManager::render(RenderWindow& window) {
    Vector2u texSize = backgroundTex.getSize();
    Vector2u winSize = window.getSize();
    float scaleX = (float)winSize.x / texSize.x;
    float scaleY = (float)winSize.y / texSize.y;
    background.setScale(scaleX, scaleY);
    window.draw(background);
    
    player->draw(window);
    
    for (int i = 0; i < maxEnemies; i++) {
        if (enemies[i]) enemies[i]->draw(window);
    }
    
    for (int i = 0; i < maxProjectiles; i++) {
        if (projectiles[i]) projectiles[i]->draw(window);
    }
    
    for (int i = 0; i < maxAsteroids; i++) {
        if (asteroids[i]) asteroids[i]->draw(window);
    }
    
    for (int i = 0; i < maxExplosions; i++) {
        if (explosions[i]) explosions[i]->draw(window);
    }
    
    if (boss && boss->isActive()) {
        boss->draw(window);
    }
    
    for (int i = 0; i < maxPowerups; i++) {
        if (powerups[i]) powerups[i]->draw(window);
    }
    
    renderUI(window);
    
    // Boss health bar
    if (boss && boss->isActive()) {
        float maxBossHealth = 500.0f;
        float currentHealth = boss->getHealth();
        float healthPercent = currentHealth / maxBossHealth;
        
        float barWidth = 300.0f;
        float barHeight = 30.0f;
        float barX = (windowWidth / 2.0f) - (barWidth / 2.0f);
        float barY = 50.0f;
        
        Text bossNameText;
        bossNameText.setFont(font);
        bossNameText.setString("BOSS");
        bossNameText.setCharacterSize(16);
        bossNameText.setFillColor(Color::Yellow);
        FloatRect nameBounds = bossNameText.getLocalBounds();
        bossNameText.setPosition(barX + (barWidth / 2.0f) - (nameBounds.width / 2.0f), barY - 25);
        window.draw(bossNameText);
        
        RectangleShape healthBarBg(Vector2f(barWidth, barHeight));
        healthBarBg.setPosition(barX, barY);
        healthBarBg.setFillColor(Color(80, 0, 0));
        healthBarBg.setOutlineThickness(3);
        healthBarBg.setOutlineColor(Color::White);
        window.draw(healthBarBg);
        
        RectangleShape healthBar(Vector2f(barWidth * healthPercent, barHeight));
        healthBar.setPosition(barX, barY);
        
        Color healthColor;
        if (healthPercent > 0.75f) {
            healthColor = Color(0, 255, 0);
        } else if (healthPercent > 0.5f) {
            healthColor = Color(255, 255, 0);
        } else if (healthPercent > 0.25f) {
            healthColor = Color(255, 165, 0);
        } else {
            healthColor = Color(255, 0, 0);
        }
        healthBar.setFillColor(healthColor);
        window.draw(healthBar);
        
        string healthStr = intToString((int)currentHealth) + " / " + intToString((int)maxBossHealth);
        Text healthNumText;
        healthNumText.setFont(font);
        healthNumText.setString(healthStr);
        healthNumText.setCharacterSize(14);
        healthNumText.setFillColor(Color::White);
        FloatRect healthBounds = healthNumText.getLocalBounds();
        healthNumText.setPosition(
            barX + (barWidth / 2.0f) - (healthBounds.width / 2.0f), 
            barY + (barHeight / 2.0f) - (healthBounds.height / 2.0f) - 2
        );
        window.draw(healthNumText);
    }
    
    if (levelTransition && textVisible) {
        window.draw(transitionText);
    }
    
    if (bossWarning && textVisible) {
        window.draw(bossWarningText);
    }
    
    if (paused) {
        window.draw(pauseText);
    }
    
    if (gameOver) {
        window.draw(gameOverText);
    }
}

void GameManager::renderUI(RenderWindow& window) {
    string scoreStr = "Score: " + intToString(player->getScore());
    scoreText.setString(scoreStr);
    
    string healthStr = "Health: " + intToString(player->getHealth());
    healthText.setString(healthStr);
    healthText.setFillColor(player->getHealth() > 50 ? Color::Green : Color::Red);
    
    string levelStr = "Level: " + intToString(currentLevel) + " Wave: " + intToString(waveNumber);
    levelText.setString(levelStr);
    
    window.draw(scoreText);
    window.draw(healthText);
    window.draw(levelText);
}

void GameManager::handleInput(Keyboard::Key key) {
    if (gameOver) return;
    
    if (!paused) {
        if (key == Keyboard::Up) player->move(0, -1);
        if (key == Keyboard::Down) player->move(0, 1);
        if (key == Keyboard::Left) player->move(-1, 0);
        if (key == Keyboard::Right) player->move(1, 0);
        if (key == Keyboard::Space) shoot();
    }
    
    if (key == Keyboard::P || key == Keyboard::Escape) {
        togglePause();
    }
}

void GameManager::shoot() {
    if (player->canFire()) {
        for (int i = 0; i < maxProjectiles; i++) {
            if (!projectiles[i] || !projectiles[i]->isActive()) {
                if (projectiles[i]) delete projectiles[i];
                
                Vector2f pos = player->getPosition();
                int damage = player->getProjectileDamage();
                projectiles[i] = new Projectile(pos.x, pos.y - 40, true, damage);
                player->resetFireTimer();
                
                shootSound.play();
                
                break;
            }
        }
    }
}

void GameManager::spawnEnemies() {
    int enemiesToSpawn = 1;
    if (currentLevel == 1) {
        enemiesToSpawn = 2;
    } else if (currentLevel == 2) {
        enemiesToSpawn = 2;
    } else if (currentLevel == 3) {
        enemiesToSpawn = 1;
    }
    
    for (int count = 0; count < enemiesToSpawn; count++) {
        for (int i = 0; i < maxEnemies; i++) {
            if (!enemies[i] || !enemies[i]->isActive()) {
                if (enemies[i]) delete enemies[i];
                
                float x = 50 + (rand() % ((int)windowWidth - 100));
                float y = -50;
                
                if (currentLevel == 1) {
                    enemies[i] = new BasicEnemy(x, y);
                } 
                else if (currentLevel == 2) {
                    int type = rand() % 100;
                    
                    if (type < 40) {
                        enemies[i] = new BasicEnemy(x, y);
                    } else {
                        enemies[i] = new AdvancedEnemy(x, y);
                    }
                } 
                else if (currentLevel == 3) {
                    int type = rand() % 100;
                    int score = player->getScore();
                    
                    if (score < 700) {
                        if (type < 60) {
                            enemies[i] = new BasicEnemy(x, y);
                        } else if (type < 85) {
                            enemies[i] = new AdvancedEnemy(x, y);
                        } else {
                            enemies[i] = new AggressiveEnemy(x, y);
                        }
                    } else {
                        if (type < 40) {
                            enemies[i] = new BasicEnemy(x, y);
                        } else if (type < 70) {
                            enemies[i] = new AdvancedEnemy(x, y);
                        } else {
                            enemies[i] = new AggressiveEnemy(x, y);
                        }
                    }
                }
                
                enemyCount++;
                break;
            }
        }
    }
}

void GameManager::spawnPowerup() {
    for (int i = 0; i < maxPowerups; i++) {
        if (!powerups[i] || !powerups[i]->isActive()) {
            if (powerups[i]) delete powerups[i];
            
            float x = 50 + (rand() % ((int)windowWidth - 100));
            float y = -20;
            
            if (currentLevel == 3 || (boss && boss->isActive())) {
                int type = rand() % 10;
                
                if (type < 4) {
                    powerups[i] = new HealthPowerUp(x, y);
                } else if (type < 7) {
                    powerups[i] = new ShieldPowerUp(x, y);
                } else if (type < 9) {
                    powerups[i] = new FireRatePowerUp(x, y);
                } else {
                    powerups[i] = new ResourcePowerUp(x, y);
                }
            }
            else if (currentLevel == 2) {
                int type = rand() % 10;
                
                if (type < 3) {
                    powerups[i] = new HealthPowerUp(x, y);
                } else if (type < 5) {
                    powerups[i] = new ShieldPowerUp(x, y);
                } else if (type < 8) {
                    powerups[i] = new FireRatePowerUp(x, y);
                } else {
                    powerups[i] = new ResourcePowerUp(x, y);
                }
            }
            else {
                int type = rand() % 10;
                
                if (type < 2) {
                    powerups[i] = new HealthPowerUp(x, y);
                } else if (type < 4) {
                    powerups[i] = new ShieldPowerUp(x, y);
                } else if (type < 7) {
                    powerups[i] = new FireRatePowerUp(x, y);
                } else {
                    powerups[i] = new ResourcePowerUp(x, y);
                }
            }
            
            powerupCount++;
            break;
        }
    }
}

void GameManager::checkCollisions() {
    FloatRect playerBounds = player->getBounds();
    
    // Boss collisions
    if (boss && boss->isActive()) {
        FloatRect bossBounds = boss->getBounds();
        
        for (int i = 0; i < maxProjectiles; i++) {
            if (projectiles[i] && projectiles[i]->isActive() && projectiles[i]->isFromPlayer()) {
                if (projectiles[i]->getBounds().intersects(bossBounds)) {
                    boss->takeDamage(projectiles[i]->getDamage());
                    projectiles[i]->setActive(false);
                    
                    if (!boss->isActive()) {
                        createExplosion(boss->getX(), boss->getY());
                        player->addScore(500);
                        enemyDeathSound.play();
                        
                        level1Music.stop();
                        level2Music.stop();
                        level3Music.stop();
                        bossMusic.stop();
                        
                        victory = true;
                        gameOver = true;
                        
                        if (scoreManager) {
                            int playTime = (clock() - startTime) / CLOCKS_PER_SEC;
                            scoreManager->addScore(playerName, player->getScore(), playTime);
                        }
                    }
                }
            }
        }
        
        if (playerBounds.intersects(bossBounds)) {
            player->takeDamage(30);
        }
    }
    
    // Projectile collisions
    for (int i = 0; i < maxProjectiles; i++) {
        if (projectiles[i] && projectiles[i]->isActive()) {
            FloatRect projBounds = projectiles[i]->getBounds();
            
            if (!projectiles[i]->isFromPlayer()) {
                if (projBounds.intersects(playerBounds)) {
                    player->takeDamage(projectiles[i]->getDamage());
                    projectiles[i]->setActive(false);
                    continue;
                }
            }
            
            if (projectiles[i]->isFromPlayer()) {
                for (int j = 0; j < maxEnemies; j++) {
                    if (enemies[j] && enemies[j]->isActive()) {
                        if (projBounds.intersects(enemies[j]->getBounds())) {
                            enemies[j]->takeDamage(projectiles[i]->getDamage());
                            projectiles[i]->setActive(false);
                            
                            if (!enemies[j]->isActive()) {
                                createExplosion(enemies[j]->getX(), enemies[j]->getY());
                                player->addScore(enemies[j]->getScoreValue());
                                Resource gained(1, 0, 1);
                                collectedResources += gained;
                                enemyDeathSound.play();
                            }
                            break;
                        }
                    }
                }
                
                for (int j = 0; j < maxAsteroids; j++) {
                    if (asteroids[j] && asteroids[j]->isActive()) {
                        if (projBounds.intersects(asteroids[j]->getBounds())) {
                            asteroids[j]->takeDamage(projectiles[i]->getDamage());
                            projectiles[i]->setActive(false);
                            
                            if (!asteroids[j]->isActive()) {
                                player->addScore(asteroids[j]->getScoreValue());
                                Resource gained(0, 1, 0);
                                collectedResources += gained;
                                enemyDeathSound.play();
                            }
                            break;
                        }
                    }
                }
            }
        }
    }
    
    // Enemy collisions
    for (int i = 0; i < maxEnemies; i++) {
        if (enemies[i] && enemies[i]->isActive()) {
            if (playerBounds.intersects(enemies[i]->getBounds())) {
                player->takeDamage(20);
                enemies[i]->setActive(false);
                createExplosion(enemies[i]->getX(), enemies[i]->getY());
            }
        }
    }
    
    // Asteroid collisions
    for (int i = 0; i < maxAsteroids; i++) {
        if (asteroids[i] && asteroids[i]->isActive()) {
            if (playerBounds.intersects(asteroids[i]->getBounds())) {
                player->takeDamage(15);
                asteroids[i]->setActive(false);
            }
        }
    }
    
    // Powerup collisions
    for (int i = 0; i < maxPowerups; i++) {
        if (powerups[i] && powerups[i]->isActive()) {
            if (playerBounds.intersects(powerups[i]->getBounds())) {
                powerups[i]->applyEffect(*player);
                powerups[i]->setActive(false);
                player->addScore(5);
                powerupSound.play();
            }
        }
    }
    
    // Update enemy targets
    for (int i = 0; i < maxEnemies; i++) {
        if (enemies[i] && enemies[i]->isActive()) {
            enemies[i]->setTarget(player->getPosition().x);
        }
    }
}

void GameManager::startLevelTransition(int newLevel) {
    levelTransition = true;
    transitionTimer = 3.0f;
    blinkTimer = 0;
    textVisible = true;
    
    string message;
    if (newLevel == 2) {
        message = "LEVEL 1 COMPLETE!\n   LEVEL 2 STARTING...";
    } else if (newLevel == 3) {
        message = "LEVEL 2 COMPLETE!\n   FINAL LEVEL!";
    }
    
    transitionText.setString(message);
    
    FloatRect textBounds = transitionText.getLocalBounds();
    transitionText.setPosition(
        (windowWidth / 2.0f) - (textBounds.width / 2.0f),
        (windowHeight / 2.0f) - (textBounds.height / 2.0f)
    );
}

void GameManager::startBossWarning() {
    bossWarning = true;
    transitionTimer = 3.0f;
    blinkTimer = 0;
    textVisible = true;
    bossWarningSound.play();
    
    for (int i = 0; i < maxEnemies; i++) {
        if (enemies[i]) {
            delete enemies[i];
            enemies[i] = nullptr;
        }
    }
}

void GameManager::spawnBoss() {
    cout << "Spawning boss!" << endl;
    if (!boss && !bossSpawned) {
        bossSpawned = true;
        boss = new Boss(windowWidth / 2, -100, windowWidth); 
        cout << "Boss created at position: " << boss->getX() << ", " << boss->getY() << endl;
        
        level1Music.stop();
        level2Music.stop();
        level3Music.stop();
        bossMusic.play();
        
        for (int i = 0; i < maxPowerups; i++) {
            if (!powerups[i] || !powerups[i]->isActive()) {
                if (powerups[i]) delete powerups[i];
                float x = 100 + (rand() % ((int)windowWidth - 200));
                powerups[i] = new HealthPowerUp(x, -20);
                break;
            }
        }
        
        for (int i = 0; i < maxPowerups; i++) {
            if (!powerups[i] || !powerups[i]->isActive()) {
                if (powerups[i]) delete powerups[i];
                float x = 100 + (rand() % ((int)windowWidth - 200));
                powerups[i] = new ShieldPowerUp(x, -50);
                break;
            }
        }
    }
}

void GameManager::bossFire() {
    if (!boss || !boss->isActive() || !boss->canFire()) return;
    
    int phase = boss->getPhase();
    Vector2f bossPos(boss->getX(), boss->getY());
    
    if (phase == 1) {
        for (int i = 0; i < maxProjectiles; i++) {
            if (!projectiles[i] || !projectiles[i]->isActive()) {
                if (projectiles[i]) delete projectiles[i];
                projectiles[i] = new Projectile(bossPos.x, bossPos.y + 60, false, 15);
                break;
            }
        }
        for (int i = 0; i < maxProjectiles; i++) {
            if (!projectiles[i] || !projectiles[i]->isActive()) {
                if (projectiles[i]) delete projectiles[i];
                projectiles[i] = new Projectile(bossPos.x - 40, bossPos.y + 60, false, 15);
                break;
            }
        }
        for (int i = 0; i < maxProjectiles; i++) {
            if (!projectiles[i] || !projectiles[i]->isActive()) {
                if (projectiles[i]) delete projectiles[i];
                projectiles[i] = new Projectile(bossPos.x + 40, bossPos.y + 60, false, 15);
                break;
            }
        }
    }
    else if (phase == 2) {
        for (int j = -2; j <= 2; j++) {
            for (int i = 0; i < maxProjectiles; i++) {
                if (!projectiles[i] || !projectiles[i]->isActive()) {
                    if (projectiles[i]) delete projectiles[i];
                    projectiles[i] = new Projectile(bossPos.x + (j * 30), bossPos.y + 60, false, 15);
                    break;
                }
            }
        }
    }
    else if (phase == 3) {
        for (int j = 0; j < 7; j++) {
            for (int i = 0; i < maxProjectiles; i++) {
                if (!projectiles[i] || !projectiles[i]->isActive()) {
                    if (projectiles[i]) delete projectiles[i];
                    float xOffset = (j - 3) * 25;
                    projectiles[i] = new Projectile(bossPos.x + xOffset, bossPos.y + 60, false, 15);
                    break;
                }
            }
        }
    }
    
    boss->resetFireTimer();
}

void GameManager::updateLevel() {
    int score = player->getScore();
    
    if (currentLevel == 3 && startingLevel == 3 && !bossSpawned && !bossWarning) {
        bossSpawnTimer += 0.016f;
        
        if (bossSpawnTimer > 5.0f) {
            startBossWarning();
            bossSpawnTimer = 0;
        }
    }
    
    if (currentLevel == 1 && score > 200 && !levelTransition) {
        currentLevel = 2;
        waveNumber++;
        startLevelTransition(2);
    } 
    else if (currentLevel == 2 && score > 500 && !levelTransition) {
        currentLevel = 3;
        waveNumber++;
        startLevelTransition(3);
        bossSpawnTimer = 0;
    }
    
    if (currentLevel == 3 && startingLevel < 3 && !bossSpawned && !bossWarning && !levelTransition) {
        bossSpawnTimer += 0.016f;
        
        if (bossSpawnTimer > 10.0f) {
            startBossWarning();
            bossSpawnTimer = 0;
        }
    }
}

void GameManager::cleanupInactive() {
    // Cleanup handled in destructor
}

void GameManager::togglePause() {
    paused = !paused;
    
    if (paused) {
        level1Music.pause();
        level2Music.pause();
        level3Music.pause();
    } else {
        if (currentLevel == 1) level1Music.play();
        else if (currentLevel == 2) level2Music.play();
        else if (currentLevel == 3) level3Music.play();
    }
}

void GameManager::restart() {
    gameOver = false;
    paused = false;
    victory = false;
    currentLevel = startingLevel;
    waveNumber = 1;
    previousLevel = startingLevel;
    levelTransition = false;
    bossWarning = false;
    bossSpawned = false;
    bossSpawnTimer = 0;

    if (boss) {
        delete boss;
        boss = nullptr;
    }
    
    for (int i = 0; i < maxEnemies; i++) {
        if (enemies[i]) {
            delete enemies[i];
            enemies[i] = nullptr;
        }
    }
    
    for (int i = 0; i < maxProjectiles; i++) {
        if (projectiles[i]) {
            delete projectiles[i];
            projectiles[i] = nullptr;
        }
    }
    
    for (int i = 0; i < maxAsteroids; i++) {
        if (asteroids[i]) {
            delete asteroids[i];
            asteroids[i] = nullptr;
        }
    }
    
    for (int i = 0; i < maxPowerups; i++) {
        if (powerups[i]) {
            delete powerups[i];
            powerups[i] = nullptr;
        }
    }
    
    for (int i = 0; i < maxExplosions; i++) {
        if (explosions[i]) {
            delete explosions[i];
            explosions[i] = nullptr;
        }
    }
    
    if (player) {
        delete player;
    }
    player = new Player(windowWidth / 2 - 25, windowHeight - 100);
    player->setBoundaries(windowWidth, windowHeight);
    
    collectedResources = Resource(0, 0, 0);
    
    spawnTimer = 0;
    powerupTimer = 0;
    
    startTime = clock();
    
    playLevelMusic(currentLevel);
}

bool GameManager::isGameOver() const {
    return gameOver;
}

bool GameManager::isPaused() const {
    return paused;
}

bool GameManager::isVictory() const {
    return victory;
}

int GameManager::getFinalScore() const {
    return player->getScore();
}

Font& GameManager::getFont() {
    return font;
}
